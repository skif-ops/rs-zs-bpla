EVT-PRE-20 REV_D10 — full procurement and production handoff
Дата / Date: 2026-10-16
Привязка исходников / Source binding: c8bf53f4c39b994b3c792aa00dee3c65edd024e1

RU
REV_D10 наследует проверенные материалы REV_D9 и закрывает недоработки инструкций,
чек-листов и операционных карт. Добавлены подробные двуязычные процедуры изготовления
жгутов, сборки и настройки станции, первого включения, EOL и монтажа на объекте.
Рабочая книга и CSV содержат полный реестр 41 станции: DIO-EVT-001...040 и DIO-EVT-B01.

Неизвестные параметры не выдуманы: усилия обжима и pull-test, моменты затяжки,
параметры герметизации и фабричные допуски внесены в реестр утверждения параметров.
До заполнения обязательных полей и приложения evidence итоговый статус остаётся HOLD.

Платы наследуются без изменения от REV_D9: PCB-MAIN 8L, PCB-PWR 4L, PCB-MIC 2L.
KiCad отсутствует в основном и Altium-архивах, но сохранён в Git и истории проекта.
Проверки DFM/first article и фактические аппаратные измерения выполняются после заказа
и сборки; итог аппаратных испытаний на дату выпуска: NOT_RUN.

EN
REV_D10 inherits the verified REV_D9 material and closes gaps in instructions,
checklists and operation cards. It adds detailed bilingual procedures for harness
manufacturing, station assembly and setup, first power, EOL and site installation.
The workbook and CSV files cover all 41 identities: DIO-EVT-001...040 and DIO-EVT-B01.

Unknown parameters are controlled rather than invented. Crimp and pull-test forces,
torques, sealing parameters and vendor tolerances are listed in the approval register.
Mandatory empty fields or missing evidence keep the result at HOLD.

PCB data is inherited unchanged from REV_D9: PCB-MAIN 8L, PCB-PWR 4L and PCB-MIC 2L.
KiCad is excluded from the full and Altium archives and remains preserved in Git/history.
Vendor DFM/first article and physical hardware measurements follow ordering and assembly;
the hardware test result at release is NOT_RUN.
