#ifndef ZS_TYPES_H
#define ZS_TYPES_H

#include <stdbool.h>
#include <stdint.h>

#define ZS_FEATURE_COUNT 43u
#define ZS_MAX_LORA_HOPS 5u
#define ZS_MODEL_MAX_CLASSES 16u
#define ZS_IMSI_CAPACITY 17u
#define ZS_ICCID_CAPACITY 23u
#define ZS_VERSION_CAPACITY 24u

typedef enum {
  ZS_CLASS_UNKNOWN = 0,
  ZS_CLASS_PISTON_UAV = 1,
  ZS_CLASS_REACTIVE_UAV = 2,
  ZS_CLASS_ELECTRIC_UAV = 3,
  ZS_CLASS_ROAD_TRAFFIC = 10,
  ZS_CLASS_AIRCRAFT = 11,
  ZS_CLASS_HELICOPTER = 12,
  ZS_CLASS_GENERATOR = 13,
  ZS_CLASS_AGRICULTURAL = 14,
  ZS_CLASS_BIRDS = 15,
  ZS_CLASS_INSECTS = 16,
  ZS_CLASS_GUNFIRE = 17,
  ZS_CLASS_WIND = 18
} zs_class_id_t;

typedef enum {
  ZS_FAMILY_UNKNOWN = 0,
  ZS_FAMILY_PROP_PISTON = 1,
  ZS_FAMILY_ROTOR_ELECTRIC = 2,
  ZS_FAMILY_TURBINE_JET = 3
} zs_family_id_t;

typedef enum {
  ZS_TYPE_UNKNOWN = 0,
  ZS_TYPE_LUTYI = 1,
  ZS_TYPE_FP1 = 2,
  ZS_TYPE_FP2 = 3,
  ZS_TYPE_OTHER = 254
} zs_type_id_t;

typedef enum {
  ZS_DECISION_UNKNOWN = 0,
  ZS_DECISION_CANDIDATE = 1,
  ZS_DECISION_PROVISIONAL = 2,
  ZS_DECISION_STABLE = 3,
  ZS_DECISION_UNSUPPORTED = 4
} zs_decision_status_t;

typedef enum {
  ZS_MOTION_UNKNOWN = 0,
  ZS_MOTION_APPROACH = 1,
  ZS_MOTION_PASSING = 2,
  ZS_MOTION_RECEDE = 3
} zs_motion_hint_t;

typedef enum {
  ZS_ROUTE_LTE = 0,
  ZS_ROUTE_NBIOT = 1,
  ZS_ROUTE_2G = 2,
  ZS_ROUTE_LORA = 3,
  ZS_ROUTE_BLE = 4,
  ZS_ROUTE_TEST = 5
} zs_route_t;

typedef enum {
  ZS_POSITION_SOURCE_GNSS_LIVE = 0,
  ZS_POSITION_SOURCE_CONFIGURED_INSTALL = 1
} zs_position_source_t;

typedef enum {
  ZS_POSITION_TRUST_UNCONFIGURED = 0,
  ZS_POSITION_TRUST_CONFIGURED_OK = 1,
  ZS_POSITION_TRUST_CONFIGURED_WARN = 2,
  ZS_POSITION_TRUST_CONFIGURED_SUSPECT = 3,
  ZS_POSITION_TRUST_REVALIDATION_REQUIRED = 4
} zs_position_trust_t;

typedef enum {
  ZS_TIME_TRUST_UNKNOWN = 0,
  ZS_TIME_TRUST_GNSS_TRUSTED = 1,
  ZS_TIME_TRUST_HOLDOVER = 2,
  ZS_TIME_TRUST_GNSS_SUSPECT = 3,
  ZS_TIME_TRUST_UNSYNCED = 4
} zs_time_trust_t;

typedef struct {
  int32_t lat_e7, lon_e7, alt_dm;
  uint16_t pos_accuracy_m;
  uint8_t altitude_source;
  uint8_t position_source;
} zs_position_t;

typedef struct {
  uint8_t fix_type, satellites;
  uint16_t hdop_x100;
  bool pps_ok, jam, spoof;
  bool position_warn, position_suspect;
  bool time_suspect, time_holdover;
  uint16_t position_delta_m;
  uint8_t position_trust;
  uint8_t time_trust;
  uint32_t expected_time_error_us;
} zs_gnss_t;

typedef struct {
  uint8_t class_id, confidence_u8;
  bool unknown;
} zs_classification_t;

typedef struct {
  uint8_t family_id;
  uint8_t family_confidence_u8;
  uint8_t type_id;
  uint8_t type_confidence_u8;
  uint8_t family_status;
  uint8_t type_status;
} zs_hier_classification_t;

typedef struct {
  int16_t height_dm;
  uint16_t height_sigma_dm;
  uint16_t speed_dmps;
  uint16_t speed_sigma_dmps;
  uint8_t confidence_u8;
  uint8_t valid_flags; /* bit0 height, bit1 speed */
  uint8_t motion_hint;
} zs_single_station_estimate_t;

typedef struct {
  uint16_t azimuth_cdeg;      /* 0..35999, clockwise from north */
  int16_t elevation_cdeg;
  uint16_t sigma_cdeg;
  bool valid;
} zs_doa_t;

typedef struct {
  int16_t tdoa12_us;
  int16_t tdoa13_us;
  int16_t tdoa14_us;
  uint16_t residual_us;
  uint8_t confidence_u8;
  uint8_t geometry_id;
  uint8_t valid_flags; /* bit0 reference TDOAs valid, bit1 direction valid */
} zs_spatial_info_t;

typedef struct {
  uint8_t battery_pct;
  uint16_t battery_mv, solar_mv;
  int16_t temperature_c10;
  uint16_t battery_bus_mv;
  int16_t battery_current_ma;
  uint32_t battery_power_mw;
  uint8_t monitor_status; /* 0 = valid INA226; nonzero = driver/status flags */
} zs_power_t;

typedef struct {
  zs_route_t transport;
  uint8_t hop_count;
  int16_t rssi_dbm, snr_db10;
  uint32_t gateway_id;
} zs_route_status_t;

typedef struct {
  char imsi[ZS_IMSI_CAPACITY];
  char iccid[ZS_ICCID_CAPACITY];
  char home_plmn[7];
  char registered_operator[32];
  char apn[64];
  char local_address[64];
  char gateway[64];
  char primary_dns[64];
  char secondary_dns[64];
  uint8_t access_technology;
  uint8_t apn_source; /* 0 none, 1 explicit, 2 network, 3 controlled catalog */
  bool settings_valid;
} zs_cellular_telemetry_t;

/* Heartbeat schema 2, key 13: health of the station detector (zs_station_pipeline) since boot. */
typedef struct {
  uint32_t boot_id;            /* NOR boot counter (zs_boot_counter); event_id = boot_id << 32 | seq_no */
  uint32_t uptime_s;
  uint32_t windows;            /* 1 s windows analysed */
  uint32_t windows_dropped;    /* hops skipped: the analysis lagged the ring */
  uint32_t confirmed_windows;  /* level 1 CONFIRMED */
  uint32_t suspect_windows;    /* level 1 SUSPECT */
  uint32_t engine_windows;     /* level 1 ENGINE_UNCONFIRMED */
  uint32_t events_emitted;
  uint32_t events_refused;     /* outbox full / storage error */
  uint32_t outbox_pending;     /* detection events still waiting for the server receipt */
  uint16_t window_max_ms;      /* longest analysis of one window since boot */
  uint8_t presence_level;      /* current level 1 (zs_presence_level_t) */
  uint8_t reset_cause;         /* key 12: why this boot started (zs_reset_cause_t: 1 power/BOR, 2 pin, 3 software, 4 IWDG, 5 WWDG, 6 low-power, 7 option bytes) */
  uint16_t watchdog_missed;    /* key 13: task-watch mask that let the IWDG fire before this boot (0 = none) */
  uint32_t params_version;     /* key 14: version of the runtime parameter set in force (CMD_SET_PARAMS; 0 = defaults) */
  uint16_t selftest_failed;    /* key 15: self-tests whose last run failed (bit = zs_selftest_id_t, zs_selftest_failed_mask; 0 = none) */
  uint64_t command_key_id;     /* key 16: id of the current command key (zs_command_key_id_u64; 0 = none provisioned) */
  uint64_t command_next_key_id; /* key 17: id of the next key while a rotation is in flight (addendum E; 0 = none) */
  uint32_t fw_version;         /* key 18: .fw_info version of the running image (addendum F; 0 = unknown) */
  uint8_t fw_state;            /* key 19: 0 idle, 1 downloading, 2 install pending, 3 trial, 4 rolled back */
  uint32_t fw_other_version;   /* key 20: version of the image in the other bank (0 = none) */
  uint32_t net_config_version; /* key 21: version of the network configuration in use (addendum G; the trial's while on trial) */
  uint8_t net_state;           /* key 22: 0 stable, 1 accepted (switch after this session), 2 trial, 3 rolled back */
  uint32_t net_failed_version; /* key 23: version of the last configuration that failed its trial (0 = none) */
} zs_detector_health_t;

typedef struct {
  uint8_t schema_ver;          /* 1: without the detector map; 2: with it when detector_present */
  uint32_t station_id;
  int64_t time_us;
  zs_position_t station;
  zs_gnss_t gnss;
  zs_power_t power;
  zs_route_status_t route;
  zs_cellular_telemetry_t cellular;
  char firmware_ver[ZS_VERSION_CAPACITY];
  char model_ver[ZS_VERSION_CAPACITY];
  char hardware_rev[ZS_VERSION_CAPACITY];
  bool self_test_ok;
  zs_detector_health_t detector;
  bool detector_present;
} zs_heartbeat_t;

typedef struct {
  uint8_t schema_ver;
  uint32_t station_id, seq_no, boot_id;
  uint64_t event_id;
  int64_t event_time_us;
  zs_position_t station;
  zs_gnss_t gnss;
  zs_classification_t classification;
  zs_hier_classification_t hierarchy;
  zs_single_station_estimate_t single_station;
  float features[ZS_FEATURE_COUNT];
  zs_doa_t doa;
  zs_spatial_info_t spatial;
  zs_power_t power;
  zs_route_status_t route;
  uint16_t sample_rate_hz;
  uint8_t detector_profile;
} zs_detection_t;

#endif
