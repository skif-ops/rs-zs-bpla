#ifndef ZS_COMMAND_H
#define ZS_COMMAND_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define ZS_COMMAND_SCHEMA_VERSION 1u
#define ZS_COMMAND_MESSAGE_TYPE 4u
#define ZS_COMMAND_ACK_MESSAGE_TYPE 5u
#define ZS_COMMAND_MAX_BYTES 2048u
#define ZS_COMMAND_ACK_MAX_BYTES 128u
#define ZS_COMMAND_KEY_ID_BYTES 8u
#define ZS_COMMAND_UUID_BYTES 16u
#define ZS_COMMAND_SIGNATURE_BYTES 64u
#define ZS_COMMAND_MAX_TTL_US UINT64_C(900000000)

typedef enum {
  ZS_COMMAND_REQUEST_AUDIO = 1,
  ZS_COMMAND_REBOOT = 2,          /* MQTT_TLS_ICD_v0_1 addendum D */
  ZS_COMMAND_SET_PARAMS = 3,      /* addendum D: bounded whitelist of runtime parameters */
  ZS_COMMAND_ROTATE_KEY = 4,      /* addendum E: install the next command public key (trusted with the current one) */
  ZS_COMMAND_UPDATE_FIRMWARE = 5, /* addendum F: fetch, verify and install a signed release in the other flash bank */
  ZS_COMMAND_SET_NETWORK = 6      /* addendum G: network configuration patch, tried and rolled back automatically */
} zs_command_code_t;

#define ZS_COMMAND_REBOOT_MAX_DELAY_S 600u
#define ZS_COMMAND_PARAMS_MAX 8u

typedef enum {
  ZS_AUDIO_SEGMENT_PRE = 0,
  ZS_AUDIO_SEGMENT_POST = 1,
  ZS_AUDIO_SEGMENT_BOTH = 2,
  ZS_AUDIO_SEGMENT_RANGE = 3
} zs_audio_segment_t;

/* CMD_REQUEST_AUDIO payload {0: event_id, 1: segment, 2: start_offset_ms|null, 3: duration_ms|null
   [, 4: event_time_us]}: the optional key 4 is the event time the server knows from the detection (MQTT ICD
   addendum B), so the station can serve events its own table no longer holds (an earlier boot). */
typedef struct {
  uint64_t event_id;
  zs_audio_segment_t segment;
  int32_t start_offset_ms;
  uint32_t duration_ms;
  bool has_range;
  bool has_event_time;
  int64_t event_time_us;
} zs_audio_request_command_t;

/* CMD_REBOOT payload {0: delay_s}: reset this many seconds after the ACK (the executor enforces a minimum). */
typedef struct {
  uint16_t delay_s;
} zs_reboot_command_t;

/* CMD_SET_PARAMS payload {0: reset_to_defaults, 1: {param_id: int32}} with strictly ascending ids.  The codec checks
   the structure; ranges and the id whitelist belong to the executor (an unknown or out-of-range id rejects the whole
   command, nothing is applied). */
typedef struct {
  bool reset_to_defaults;
  uint8_t count;
  uint16_t id[ZS_COMMAND_PARAMS_MAX];
  int32_t value[ZS_COMMAND_PARAMS_MAX];
} zs_set_params_command_t;

/* CMD_ROTATE_COMMAND_KEY payload {0: bstr(32)}: the raw Ed25519 public key the server will sign with next.  The
   codec checks the structure; zero or already-trusted keys belong to the executor (zs_command_keys). */
typedef struct {
  uint8_t public_key[32];
} zs_rotate_key_command_t;

/* CMD_UPDATE_FIRMWARE payload {0: manifest bstr(1..96), 1: release key id bstr(8), 2: release signature bstr(64)}:
   the codec checks the structure; the release signature, target, version and size belong to zs_fw_update_check. */
#define ZS_COMMAND_FW_MANIFEST_MAX 96u
typedef struct {
  uint8_t manifest[ZS_COMMAND_FW_MANIFEST_MAX];
  uint8_t manifest_size;
  uint8_t key_id[8];
  uint8_t signature[64];
} zs_update_firmware_command_t;

/* CMD_SET_NETWORK_CONFIG payload {0: bstr(1..240)}: a station configuration patch in the BLE config_write format
   (STATION_CONFIG_CBOR_v0_1 §2-3).  The codec checks the structure; the patch itself belongs to zs_net_trial. */
#define ZS_COMMAND_NET_PATCH_MAX 240u
typedef struct {
  uint8_t patch[ZS_COMMAND_NET_PATCH_MAX];
  uint8_t patch_size;
} zs_set_network_command_t;

typedef struct {
  uint32_t station_id;
  uint8_t command_id[ZS_COMMAND_UUID_BYTES];
  uint64_t created_time_us;
  uint64_t expires_time_us;
  zs_command_code_t code;
  zs_audio_request_command_t audio;
  zs_reboot_command_t reboot;
  zs_set_params_command_t params;
  zs_rotate_key_command_t rotate;
  zs_update_firmware_command_t firmware;
  zs_set_network_command_t network;
  uint8_t key_id[ZS_COMMAND_KEY_ID_BYTES];
} zs_command_t;

typedef enum {
  ZS_COMMAND_STATUS_OK = 0,
  ZS_COMMAND_STATUS_INVALID_ARGUMENT,
  ZS_COMMAND_STATUS_INVALID_CBOR,
  ZS_COMMAND_STATUS_UNSUPPORTED,
  ZS_COMMAND_STATUS_STATION_MISMATCH,
  ZS_COMMAND_STATUS_TIME_UNTRUSTED,
  ZS_COMMAND_STATUS_NOT_YET_VALID,
  ZS_COMMAND_STATUS_EXPIRED,
  ZS_COMMAND_STATUS_INVALID_TTL,
  ZS_COMMAND_STATUS_SIGNATURE_REJECTED,
  ZS_COMMAND_STATUS_DEDUP_REQUIRED,
  ZS_COMMAND_STATUS_DEDUP_STORAGE_ERROR,
  ZS_COMMAND_STATUS_DUPLICATE,
  ZS_COMMAND_STATUS_WORKSPACE_TOO_SMALL
} zs_command_status_t;

typedef bool (*zs_command_signature_verify_fn)(
    void *ctx,
    const uint8_t key_id[ZS_COMMAND_KEY_ID_BYTES],
    const uint8_t *signed_cbor,
    size_t signed_cbor_size,
    const uint8_t signature[ZS_COMMAND_SIGNATURE_BYTES]);

typedef enum {
  ZS_COMMAND_DEDUP_NOT_SEEN = 0,
  ZS_COMMAND_DEDUP_SEEN,
  ZS_COMMAND_DEDUP_ERROR
} zs_command_dedup_state_t;

typedef zs_command_dedup_state_t (*zs_command_dedup_lookup_fn)(
    void *ctx, const uint8_t command_id[ZS_COMMAND_UUID_BYTES]);

typedef enum {
  ZS_COMMAND_ACK_OK = 0,
  ZS_COMMAND_ACK_REJECTED = 1,
  ZS_COMMAND_ACK_FAILED = 2,
  ZS_COMMAND_ACK_EXPIRED = 3
} zs_command_ack_result_t;

/*
 * The verifier must resolve key_id only through the provisioned production
 * trust store and verify Ed25519 over signed_cbor. The dedup callback must read
 * durable state. An OK result establishes eligibility only: the caller must
 * execute idempotently and durably record the command result before publishing
 * its ACK. DUPLICATE must never repeat the command side effect.
 */
zs_command_status_t zs_command_decode_verify(
    const uint8_t *payload,
    size_t payload_size,
    uint32_t expected_station_id,
    uint64_t now_us,
    bool time_trusted,
    zs_command_signature_verify_fn verify,
    void *verify_ctx,
    zs_command_dedup_lookup_fn dedup_lookup,
    void *dedup_ctx,
    uint8_t *workspace,
    size_t workspace_size,
    zs_command_t *command);

size_t zs_command_encode_ack(
    uint32_t station_id,
    const uint8_t command_id[ZS_COMMAND_UUID_BYTES],
    zs_command_ack_result_t result,
    uint64_t completed_time_us,
    uint16_t detail_code,
    uint8_t *output,
    size_t output_size);

const char *zs_command_status_name(zs_command_status_t status);

#endif
