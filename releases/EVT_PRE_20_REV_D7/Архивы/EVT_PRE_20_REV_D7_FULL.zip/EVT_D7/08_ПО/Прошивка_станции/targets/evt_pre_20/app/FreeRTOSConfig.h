/* FreeRTOS V11.1.0 configuration for Dioneya EVT-PRE-20 (STM32U585, Cortex-M33, TrustZone disabled). */
#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#include <stdint.h>
extern uint32_t SystemCoreClock;

#define configENABLE_FPU                          1
#define configENABLE_MPU                          0
#define configENABLE_TRUSTZONE                    0
#define configRUN_FREERTOS_SECURE_ONLY            1

#define configUSE_PREEMPTION                      1
#define configUSE_TIME_SLICING                    0
#define configUSE_PORT_OPTIMISED_TASK_SELECTION   0
#define configUSE_TICKLESS_IDLE                   0   /* tickless on LPTIM lands with the STOP2 work (plan B3) */
#define configCPU_CLOCK_HZ                        (SystemCoreClock)
#define configTICK_RATE_HZ                        ((TickType_t)1000)
#define configMAX_PRIORITIES                      (8)
#define configMINIMAL_STACK_SIZE                  ((uint16_t)256)
#define configMAX_TASK_NAME_LEN                   (12)
#define configTICK_TYPE_WIDTH_IN_BITS             TICK_TYPE_WIDTH_32_BITS
#define configIDLE_SHOULD_YIELD                   1
#define configUSE_TASK_NOTIFICATIONS              1
#define configTASK_NOTIFICATION_ARRAY_ENTRIES     2
#define configUSE_MUTEXES                         1
#define configUSE_RECURSIVE_MUTEXES               1
#define configUSE_COUNTING_SEMAPHORES             1
#define configQUEUE_REGISTRY_SIZE                 8
#define configUSE_QUEUE_SETS                      0
#define configUSE_NEWLIB_REENTRANT                0
#define configENABLE_BACKWARD_COMPATIBILITY       0
#define configNUM_THREAD_LOCAL_STORAGE_POINTERS   0
#define configUSE_MINI_LIST_ITEM                  1
#define configSTACK_DEPTH_TYPE                    uint16_t
#define configMESSAGE_BUFFER_LENGTH_TYPE          size_t

/* Memory: static heap_4 of 52 KB for the ten task stacks (~41 KB) and their TCBs (budget asserted in tasks.c); the audio
   ring, DMA buffers, the DSP scratch and the NOR mutex are static. */
#define configSUPPORT_STATIC_ALLOCATION           1
#define configSUPPORT_DYNAMIC_ALLOCATION          1
#define configTOTAL_HEAP_SIZE                     ((size_t)(52 * 1024))   /* task stacks + TCBs; checked in tasks.c */
#define configAPPLICATION_ALLOCATED_HEAP          0

/* Hooks and diagnostics. */
#define configUSE_IDLE_HOOK                       0
#define configUSE_TICK_HOOK                       0
#define configCHECK_FOR_STACK_OVERFLOW            2
#define configUSE_MALLOC_FAILED_HOOK              1
#define configUSE_DAEMON_TASK_STARTUP_HOOK        0
#define configGENERATE_RUN_TIME_STATS             0
#define configUSE_TRACE_FACILITY                  1
#define configUSE_STATS_FORMATTING_FUNCTIONS      0

/* Software timers (service window, heartbeat). */
#define configUSE_TIMERS                          1
#define configTIMER_TASK_PRIORITY                 (configMAX_PRIORITIES - 2)
#define configTIMER_QUEUE_LENGTH                  8
#define configTIMER_TASK_STACK_DEPTH              (configMINIMAL_STACK_SIZE * 2)

/* Interrupt priorities: 4 preemption bits on Cortex-M33; ISRs that call FreeRTOS APIs must be >= 5. */
#define configPRIO_BITS                           4
#define configLIBRARY_LOWEST_INTERRUPT_PRIORITY   15
#define configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY 5
#define configKERNEL_INTERRUPT_PRIORITY           (configLIBRARY_LOWEST_INTERRUPT_PRIORITY << (8 - configPRIO_BITS))
#define configMAX_SYSCALL_INTERRUPT_PRIORITY      (configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY << (8 - configPRIO_BITS))
#define configMAX_API_CALL_INTERRUPT_PRIORITY     configMAX_SYSCALL_INTERRUPT_PRIORITY

#define configASSERT(x) do { if ((x) == 0) { taskDISABLE_INTERRUPTS(); for (;;) {} } } while (0)

#define INCLUDE_vTaskPrioritySet                  1
#define INCLUDE_uxTaskPriorityGet                 1
#define INCLUDE_vTaskDelete                       1
#define INCLUDE_vTaskSuspend                      1
#define INCLUDE_xTaskDelayUntil                   1
#define INCLUDE_vTaskDelay                        1
#define INCLUDE_xTaskGetSchedulerState            1
#define INCLUDE_xTaskGetCurrentTaskHandle         1
#define INCLUDE_uxTaskGetStackHighWaterMark       1
#define INCLUDE_xTimerPendFunctionCall            1
#define INCLUDE_xTaskGetIdleTaskHandle            1

/* Kernel handlers from the CM33 port are wired to the CMSIS vector names. */
#define vPortSVCHandler    SVC_Handler
#define xPortPendSVHandler PendSV_Handler
#define xPortSysTickHandler SysTick_Handler

#endif
