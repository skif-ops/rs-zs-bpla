# EVT-PRE-20 Rev.A — доверенные координаты установки и GNSS integrity

Статус: `LOCKED ARCHITECTURE / PORTABLE STORE+BLE GUARD IMPLEMENTED / FLASH+NRF GATT BINDING OPEN`

Основание: `DEC-018`.

## 1. Основной принцип

EVT-PRE-20 является стационарной системой. После commissioning физические координаты станции не должны автоматически изменяться вслед за текущим решением GNSS.

Для каждой станции сохраняется `installation_position`:
- latitude в `lat_e7`;
- longitude в `lon_e7`;
- высота MSL в `alt_dm`;
- оценка точности ввода `accuracy_m`;
- источник координат: `manual`, `phone_location`, `station_gnss_snapshot` или `surveyed`;
- версия конфигурации;
- флаг блокировки;
- commissioning record/hash и audit metadata.

После успешного commissioning именно `installation_position` является авторитетной позицией станции для сервера, межстанционной геометрии и TDOA.

Wi-Fi/BSSID geolocation для EVT-PRE-20 не требуется. Wi-Fi не обеспечивает необходимую точность геометрии и не является источником высокоточного времени.

## 2. Роль GNSS после commissioning

GNSS используется для:
1. PPS/time synchronization при доверенном состоянии времени;
2. контроля текущего GNSS position относительно `installation_position`;
3. мониторинга spoofing/jamming flags приёмника;
4. диагностики количества спутников, HDOP, reported accuracy и RF integrity;
5. обнаружения возможного реального перемещения станции совместно с акселерометром/tamper.

Текущее GNSS position после commissioning не заменяет `installation_position` автоматически.

## 3. Position trust states

- `UNCONFIGURED`: доверенные координаты ещё не заданы; изделие не получает статус FIELD_READY.
- `CONFIGURED_OK`: GNSS согласуется с установленными координатами.
- `CONFIGURED_WARN`: устойчивое превышение warning threshold.
- `CONFIGURED_SUSPECT`: spoof detector или устойчивое превышение suspect threshold / gross jump.
- `REVALIDATION_REQUIRED`: станция физически перемещалась или координаты были изменены в service mode.

Начальные EVT-PRE-20 thresholds:
- warning distance: 25 m;
- suspect distance: 75 m;
- gross single-fix jump: 250 m;
- warning persistence: 3 valid fixes;
- suspect persistence: 10 valid fixes.

Для учёта обычной ошибки GNSS эффективный warning threshold должен быть не меньше `max(25 m, 3 × reported horizontal accuracy)`, suspect threshold — не меньше `max(75 m, 5 × reported horizontal accuracy)`.

Spoofing indication приёмника переводит position trust в `CONFIGURED_SUSPECT` без ожидания distance persistence. Jamming отдельно фиксируется как RF-integrity fault и учитывается вместе с потерей/деградацией fix.

## 4. Effective station position

Если `installation_position.locked == true`, во всех detection/heartbeat данных поле `station` содержит сконфигурированные координаты установки.

GNSS observed position передаётся только как diagnostic/integrity information и не используется сервером для изменения station geometry.

Если станция ещё не commissioned, GNSS position может отображаться в service UI, но такое изделие не допускается к полевому режиму и полноценной TDOA геометрии.

## 5. Time trust отдельно от position trust

Фиксированные координаты не защищают от подмены GNSS времени.

Отдельно поддерживаются состояния:
- `GNSS_TIME_TRUSTED`;
- `HOLDOVER`;
- `GNSS_TIME_SUSPECT`;
- `UNSYNCED`.

При GNSS spoof/jam, необъяснимом скачке времени или PPS integrity fault:
- GNSS PPS не считается автоматически доверенным;
- станция переходит в holdover на SiT1552 32.768 kHz, если предыдущая дисциплина времени была валидна;
- продолжительность, в течение которой holdover допустим для TDOA, определяется только измеренной на EVT стабильностью, а не теоретической оценкой;
- после исчерпания подтверждённого holdover interval TDOA помечается degraded/invalid, при этом акустическое обнаружение и классификация продолжают работать.

### 5.1 Реализация в прошивке (2026-10-01, `firmware/include/zs_time.h`)

- Пока у станции есть своя шкала времени (доверенная, удержание или непроверенная), метка каждого PPS сверяется со
  временем, которое шкала предсказывает для отсчёта PPS: допуск 1 мс + 200 ppm от времени после последнего принятого
  PPS (кварц HSE ±50 ppm и оценка частоты с запасом); сразу после паузы захвата (S3/S0, её длину тик MCU знает с
  точностью до миллисекунд) — 250 мс, то есть проверяются только целые секунды.
- Метка вне допуска — скачок времени: PPS не принимается, станция остаётся на своей шкале (`HOLDOVER` с растущей
  ожидаемой ошибкой), время помечается подозрительным (`time_suspect` в heartbeat и детекции, флаг 0x20 сводки).
  Пеленги в удержании по-прежнему сливаются сервером. Флаг снимается после 10 PPS подряд, снова согласных со шкалой.
- Скачок, который держится дольше удержания (120 с): своей шкалы больше нет, станция берёт шкалу GNSS, но
  непроверенной — доверие `GNSS_TIME_SUSPECT` (сервер такие пеленги не сливает, команды проверяются по сетевому
  времени). Сразу, если не меньше 10 отвергнутых меток подряд согласны между собой, иначе со следующего PPS.
  Непроверенная шкала становится доверенной после 600 с PPS без нового скачка и без сообщения приёмника о подмене.
- Первый PPS после включения сверять не с чем: он принимается как есть (непроверенным, если приёмник уже сообщает о
  подмене). Медленный увод PPS в пределах допуска кварца изнутри станции не обнаружить.
- Пока GNSS подозрителен, его координаты тоже не принимаются: станция с координатами монтажника помечает фикс как
  подозрительный (`receiver_spoof` в `zs_position_trust_update` → `CONFIGURED_SUSPECT`), станция без них сохраняет
  последний фикс до подозрения (`zs_station_position_set_gnss_suspect`).
- Вход для собственного флага подмены приёмника: `zs_time_set_receiver_spoof`. Источника у него пока нет: сообщение
  UBX-SEC-SIG (состояние обнаружения подмены и глушения) появилось в прошивке u-blox M10 SPG 5.30, а MAX-M10S
  (BOM, U9) работает на ПЗУ-прошивке SPG 5.10 без обновления; прошивку SPG 5.30 с флеш-обновлением имеет MAX-M10N.
  Решение заказчика (2026-10-01): BOM ушёл в закупку, MAX-M10S остаётся; на образце проверить, выставляет ли он
  признак подмены `spoofDetState` в UBX-NAV-STATUS (если да — он и станет источником `zs_time_set_receiver_spoof`);
  замена приёмника на MAX-M10N — вопрос промышленной партии. До тех пор подмену выдают скачок PPS и, у станции с
  координатами монтажника, расхождение фикса с ними.
- Консоль: `pps` печатает `time suspect/verified/jumps/last_jump_ms/reanchors`. Тест: `firmware/tests/test_time_spoof.c`.

## 6. Android commissioning workflow

Приложение должно работать без Google Play Services.

Шаги:
1. Вход в физический service mode станции.
2. BLE Secure Connections + проверка QR/serial.
3. Экран `Координаты установки`.
4. Выбор источника:
   - ручной ввод;
   - координаты телефона через Android framework location API;
   - текущий GNSS fix станции;
   - геодезические/заранее известные координаты.
5. Отображение latitude, longitude, altitude, accuracy/source и текущего расхождения с GNSS станции.
6. Явное подтверждение оператора с отображением serial станции.
7. Атомарная запись `installation_position` и `position_trust_policy` по authenticated BLE.
8. Read-back и сравнение version/hash.
9. Lock coordinates.
10. Экспорт commissioning record с serial, координатами, источником, точностью, временем, версиями HW/FW/app и hash конфигурации.

Повторное изменение координат допускается только после нового физического service mode и авторизованной роли. Оно создаёт отдельную audit запись и переводит станцию в `REVALIDATION_REQUIRED` до завершения self-test.

### 6.1 Атомарное хранение на станции

Portable firmware сохраняет запись в двух чередующихся слотах по 96 байт. Новая
версия сначала записывается в стёртый неактивный слот с generation и CRC32, а
commit-marker записывается последней операцией. После записи выполняются полный
read-back, CRC и сравнение полей. При сбое питания до commit-marker предыдущий
слот остаётся авторитетным.

Storage format `2` требует не просто ненулевой commissioning hash, а точное
совпадение со станционным каноническим SHA-256. Предыдущий host-only format `1`
не мигрируется и отклоняется; серийных/EVT-станций с ним ещё не создавалось.

Первая запись и recommission разрешены только при одновременно активном
физическом service mode и подтверждённой локальной роли. Для locked-записи
recommission должен быть указан явно, а `version` обязан монотонно увеличиваться.
Нулевой commissioning hash и невалидные координаты/thresholds отклоняются до
операции erase.

CRC не заменяет BLE Secure Connections, авторизацию роли или commissioning
hash. Текущий модуль задаёт переносимый формат и power-loss-safe алгоритм;
STM32 Flash binding, адреса страниц, endurance и fault-injection на целевой плате
остаются открытыми до target port и аппаратного EVT.

### 6.2 Portable BLE commissioning guard

Перед storage-модулем добавлена transport-independent граница, предназначенная
для будущей привязки nRF52840 GATT к STM32. Она отклоняет MQTT/HTTPS origin,
требует BLE Secure Connections, проверенного peer, авторизованной роли,
физического service mode и возраста окна не более 600000 ms. Настройки trust,
отличные от defaults 25/75/250 m и 3/10 fixes, доступны только engineer-роли.

Приложение не назначает доверенный hash. Станция вычисляет SHA-256 по 58-байтной
канонической big-endian записи с domain `ZS-INSTALLATION-V1`; storage generation
и само поле hash в digest не входят. Audit intent обязан сохраниться до erase,
после atomic commit выполняются load/read-back, повторная проверка hash и audit
committed. Если audit finalize не подтверждён после уже выполненной записи,
возвращается отдельное состояние, и FIELD_READY остаётся запрещённым.

| Offset | Bytes | Поле |
|---:|---:|---|
| 0 | 18 | ASCII `ZS-INSTALLATION-V1` |
| 18 | 1 | canonical hash format `1` |
| 19 | 1 | configured = `1` |
| 20 | 1 | locked = `1` |
| 21 | 1 | source: manual `0`, phone `1`, station GNSS `2`, surveyed `3` |
| 22 | 1 | altitude source = configured MSL `1` |
| 23 | 1 | position source = configured install `1` |
| 24 | 4 | configuration version, unsigned big-endian |
| 28 | 4 | lat_e7, signed two's-complement big-endian |
| 32 | 4 | lon_e7, signed two's-complement big-endian |
| 36 | 4 | alt_dm, signed two's-complement big-endian |
| 40 | 2 | accuracy_m, unsigned big-endian |
| 42 | 2 | warning distance, unsigned big-endian |
| 44 | 2 | suspect distance, unsigned big-endian |
| 46 | 2 | gross-jump distance, unsigned big-endian |
| 48 | 1 | warning consecutive fixes |
| 49 | 1 | suspect consecutive fixes |
| 50 | 8 | commissioned_time_us, unsigned big-endian |

Operation initial/recommission, storage generation, audit phase and digest bytes
не входят в эти 58 bytes. Они проверяются отдельно соответствующим state/store
контрактом.

Portable guard не подтверждает UUID/MTU, nRF52840 firmware, UART binding,
реальный service-mode timer или durable audit storage. Эти части и аппаратное
fault injection остаются открытыми.

## 7. BLE configuration objects

### installation_position
- `lat_e7: int32`
- `lon_e7: int32`
- `alt_dm: int32`
- `accuracy_m: uint16`
- `source: enum`
- `version: uint32`
- `locked: bool`

### position_trust_policy
- `warning_distance_m: uint16` default 25
- `suspect_distance_m: uint16` default 75
- `gross_jump_distance_m: uint16` default 250
- `warning_consecutive_fixes: uint8` default 3
- `suspect_consecutive_fixes: uint8` default 10

### gnss_integrity_status
Read/notify diagnostic object:
- observed GNSS coordinates;
- horizontal accuracy;
- distance from configured position;
- fix type / satellites / HDOP;
- receiver spoof state;
- receiver jamming/interference state;
- position trust state;
- time trust state;
- PPS state / expected time error;
- station movement/revalidation flag.

## 8. Server/Mukhoyed rules

- station registry stores authoritative configured coordinates independently of incoming GNSS observations;
- incoming `station` position is checked against registry and may not silently overwrite it;
- TDOA/fusion uses configured installation coordinates;
- mismatch, spoof, jam and time-integrity states are persisted as diagnostics/security events;
- server UI shows both `Установлено` and `GNSS сейчас`, plus delta when observed GNSS telemetry is available;
- any remote coordinate-change command is rejected for EVT-PRE-20; coordinate change is local commissioning only.

## 9. EVT tests

Mandatory:
- manual coordinate commissioning + read-back;
- commissioning from phone location without GMS;
- commissioning from station GNSS snapshot;
- reject invalid latitude/longitude/altitude/accuracy;
- power cycle retains locked coordinates;
- GNSS offset 10 m: no alert;
- sustained offset > warning threshold: WARN but configured position remains effective;
- sustained offset > suspect threshold: SUSPECT and configured position remains effective;
- gross jump > 250 m: immediate suspect;
- injected receiver spoof flag: immediate suspect;
- jamming/loss of fix: RF integrity fault without station-position drift;
- physical movement detected by accelerometer/tamper: REVALIDATION_REQUIRED;
- attempt remote coordinate modification: rejected;
- coordinate modification in authorized physical service mode: audit record required;
- GNSS time jump/spoof: independent TIME_SUSPECT/HOLDOVER behavior;
- TDOA uses installation coordinates under simulated GNSS drift.

## 10. Release gate

FIELD_READY is prohibited unless installation coordinates are present, validated, read back, locked and included in commissioning record.
