"""Compact CBOR codec shared with ZS-BPLA firmware protocol."""
from __future__ import annotations

import struct
from typing import Any

from station.schemas import (
    Classification,
    CellularTelemetry,
    DetectionMessage,
    DetectorHealth,
    DoaEstimate,
    GnssStatus,
    HeartbeatMessage,
    HierarchicalClassification,
    PowerStatus,
    RouteStatus,
    SingleStationEstimate,
    SpatialInfo,
    StationPosition,
)

_MSG_DETECTION = 2
_MSG_HEARTBEAT = 3
_SUPPORTED_DETECTION_SCHEMAS = frozenset({1, 3, 4})
_FW_STATE = {0: "IDLE", 1: "DOWNLOADING", 2: "INSTALL_PENDING", 3: "TRIAL", 4: "ROLLED_BACK"}   # addendum F, key 19
_NET_STATE = {0: "STABLE", 1: "ACCEPTED", 2: "TRIAL", 3: "ROLLED_BACK"}                        # addendum G, key 22
_RESET_CAUSE = {1: "POWER", 2: "PIN", 3: "SOFTWARE", 4: "IWDG", 5: "WWDG", 6: "LOW_POWER", 7: "OPTION_BYTES"}
_SUPPORTED_HEARTBEAT_SCHEMAS = frozenset({1, 2})   # 2 adds the optional detector map (key 13)
_ROUTE = {0: "LTE", 1: "NB_IOT", 2: "2G", 3: "LORA", 4: "BLE", 5: "TEST"}
_PROFILE = {0: "generic", 1: "piston", 2: "reactive"}
_CLASS_LABEL = {
    0: "UNKNOWN",
    1: "PISTON_UAV",
    2: "REACTIVE_UAV",
    3: "ELECTRIC_UAV",
    10: "ROAD_TRAFFIC",
    11: "AIRCRAFT",
    12: "HELICOPTER",
    13: "GENERATOR",
    14: "AGRICULTURAL",
    15: "BIRDS",
    16: "INSECTS",
    17: "GUNFIRE",
    18: "WIND",
}
_FAMILY_LABEL = {0: "UNKNOWN", 1: "PROP_PISTON", 2: "ROTOR_ELECTRIC", 3: "TURBINE_JET"}
_TYPE_LABEL = {0: "UNKNOWN", 1: "LUTYI", 2: "FP1", 3: "FP2", 254: "OTHER"}
_DECISION_STATUS = {0: "UNKNOWN", 1: "CANDIDATE", 2: "PROVISIONAL", 3: "STABLE", 4: "UNSUPPORTED"}
_MOTION_HINT = {0: "UNKNOWN", 1: "APPROACH", 2: "PASSING", 3: "RECEDING"}
_POSITION_TRUST = {
    0: "UNCONFIGURED",
    1: "CONFIGURED_OK",
    2: "CONFIGURED_WARN",
    3: "CONFIGURED_SUSPECT",
    4: "REVALIDATION_REQUIRED",
}
_TIME_TRUST = {
    0: "UNKNOWN",
    1: "GNSS_TIME_TRUSTED",
    2: "HOLDOVER",
    3: "GNSS_TIME_SUSPECT",
    4: "UNSYNCED",
}
_ALTITUDE_SOURCE = {0: "gnss_msl", 1: "configured_msl", 2: "unknown"}
_POSITION_SOURCE = {0: "gnss_live", 1: "configured_install"}
_APN_SOURCE = {1: "EXPLICIT", 2: "NETWORK", 3: "CATALOG"}
_PRESENCE_LEVEL = {0: "NONE", 1: "SUSPECT", 2: "ENGINE_UNCONFIRMED", 3: "CONFIRMED"}   # firmware zs_presence_level_t


class _CborReader:
    def __init__(self, raw: bytes):
        self.raw = memoryview(raw)
        self.i = 0

    def take(self, n: int) -> bytes:
        if self.i + n > len(self.raw):
            raise ValueError("truncated CBOR")
        b = self.raw[self.i : self.i + n].tobytes()
        self.i += n
        return b

    def arg(self, ai: int) -> int:
        if ai < 24:
            return ai
        if ai == 24:
            return self.take(1)[0]
        if ai == 25:
            return int.from_bytes(self.take(2), "big")
        if ai == 26:
            return int.from_bytes(self.take(4), "big")
        if ai == 27:
            return int.from_bytes(self.take(8), "big")
        raise ValueError("indefinite/reserved CBOR not supported")

    def item(self):
        ib = self.take(1)[0]
        major, ai = ib >> 5, ib & 31
        if major in (0, 1):
            v = self.arg(ai)
            return v if major == 0 else -1 - v
        if major in (2, 3):
            n = self.arg(ai)
            b = self.take(n)
            return b if major == 2 else b.decode("utf-8")
        if major == 4:
            return [self.item() for _ in range(self.arg(ai))]
        if major == 5:
            return {self.item(): self.item() for _ in range(self.arg(ai))}
        if major == 7:
            if ai == 20:
                return False
            if ai == 21:
                return True
            if ai == 22:
                return None
            if ai == 25:
                return struct.unpack(">e", self.take(2))[0]
            if ai == 26:
                return struct.unpack(">f", self.take(4))[0]
            if ai == 27:
                return struct.unpack(">d", self.take(8))[0]
        raise ValueError(f"unsupported CBOR major={major} ai={ai}")


def decode_cbor(raw: bytes):
    r = _CborReader(raw)
    obj = r.item()
    if r.i != len(r.raw):
        raise ValueError("trailing CBOR bytes")
    return obj


def _as_map(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _key_id_hex(value: object) -> str | None:
    """Heartbeat detector keys 16/17 (ICD addendum E): a command key id as uint64, 0 = none."""
    if type(value) is not int or not 0 <= value <= 0xFFFFFFFFFFFFFFFF:
        raise ValueError("command key id must be a uint64")
    return None if value == 0 else value.to_bytes(8, "big").hex()


def _text_field(values: dict, key: int, name: str) -> str:
    value = values.get(key, "")
    if not isinstance(value, str):
        raise ValueError(f"compact {name} must be text")
    return value


def _integer_field(values: dict, key: int, name: str) -> int:
    value = values.get(key, 0)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"compact {name} must be an integer")
    return value


def _f16_le_bytes(raw: bytes) -> list[float]:
    if len(raw) % 2:
        raise ValueError("float16 feature payload length must be even")
    return [float(x) for x in struct.unpack("<" + "e" * (len(raw) // 2), raw)]


def decode_detection_obj(obj: Any) -> DetectionMessage:
    if not isinstance(obj, dict):
        raise ValueError("compact detection must be a CBOR map")
    schema_ver = int(obj.get(0, -1))
    if schema_ver not in _SUPPORTED_DETECTION_SCHEMAS:
        raise ValueError(f"unsupported compact detection schema: {schema_ver}")
    if int(obj.get(1, -1)) != _MSG_DETECTION:
        raise ValueError("unsupported compact message type")

    payload = _as_map(obj.get(8))
    status = _as_map(obj.get(10))
    doa = _as_map(obj.get(11))
    hierarchy = _as_map(obj.get(12))
    single = _as_map(obj.get(13))
    spatial = _as_map(obj.get(14))

    raw_features = obj.get(9, b"")
    if raw_features and not isinstance(raw_features, (bytes, bytearray)):
        raise ValueError("compact features must be bytes")
    features = _f16_le_bytes(bytes(raw_features)) if raw_features else []
    if features and len(features) != 43:
        raise ValueError(f"expected 43 compact features, got {len(features)}")

    class_id = int(payload.get(4, 0))
    confidence = int(payload.get(5, 0))
    flags = int(obj.get(7, 0))
    configured_position = bool(flags & 0x04)

    family_id = int(hierarchy.get(0, 0))
    type_id = int(hierarchy.get(2, 0))
    valid_flags = int(single.get(5, 0))
    spatial_flags = int(spatial.get(6, 0))
    position_trust_id = int(payload.get(13, 1 if configured_position else 0))
    time_trust_id = int(payload.get(14, 0))

    return DetectionMessage(
        schema_ver=schema_ver,
        station_id=int(obj.get(2, 0)),
        seq_no=int(obj.get(3, 0)),
        boot_id=int(obj.get(4, 0)),
        event_id=int(obj.get(5, 0)),
        event_time_us=int(obj.get(6, 0)),
        station=StationPosition(
            lat_e7=int(payload.get(0, 0)),
            lon_e7=int(payload.get(1, 0)),
            alt_dm=int(payload.get(2, 0)),
            pos_accuracy_m=float(payload.get(15, 20)),
            altitude_source="configured_msl" if configured_position else "gnss_msl",
            position_source="configured_install" if configured_position else "gnss_live",
        ),
        gnss=GnssStatus(
            fix_type=int(payload.get(6, 0)),
            satellites=int(payload.get(7, 0)),
            hdop_x100=int(payload.get(8, 9999)),
            pps_ok=bool(payload.get(3, False)),
            expected_time_error_us=int(payload.get(9, 1_000_000)),
            jam=bool(flags & 0x01),
            spoof=bool(flags & 0x02),
            position_delta_m=int(payload.get(12, 0)),
            position_warn=bool(flags & 0x08),
            position_suspect=bool(flags & 0x10),
            time_suspect=bool(flags & 0x20),
            time_holdover=bool(flags & 0x40),
            position_trust=_POSITION_TRUST.get(position_trust_id, "UNCONFIGURED"),
            time_trust=_TIME_TRUST.get(time_trust_id, "UNKNOWN"),
        ),
        classification=Classification(
            class_id=class_id,
            label=_CLASS_LABEL.get(class_id, f"CLASS_{class_id}"),
            confidence_u8=confidence,
            unknown=(class_id == 0),
        ),
        hierarchy=HierarchicalClassification(
            family_id=family_id,
            family_label=_FAMILY_LABEL.get(family_id, f"FAMILY_{family_id}"),
            family_confidence_u8=int(hierarchy.get(1, 0)),
            family_status=_DECISION_STATUS.get(int(hierarchy.get(4, 0)), "UNKNOWN"),
            type_id=type_id,
            type_label=_TYPE_LABEL.get(type_id, f"TYPE_{type_id}"),
            type_confidence_u8=int(hierarchy.get(3, 0)),
            type_status=_DECISION_STATUS.get(int(hierarchy.get(5, 0)), "UNKNOWN"),
        ),
        single_station_estimate=SingleStationEstimate(
            height_dm=int(single.get(0, 0)),
            height_sigma_dm=int(single.get(1, 0)),
            speed_dmps=int(single.get(2, 0)),
            speed_sigma_dmps=int(single.get(3, 0)),
            confidence_u8=int(single.get(4, 0)),
            height_valid=bool(valid_flags & 0x01),
            speed_valid=bool(valid_flags & 0x02),
            motion_hint=_MOTION_HINT.get(int(single.get(6, 0)), "UNKNOWN"),
        ),
        features=features,
        doa=DoaEstimate(
            azimuth_cdeg=int(doa.get(0, 0)),
            elevation_cdeg=int(doa.get(1, 0)),
            sigma_cdeg=int(doa.get(2, 18000)),
            valid=bool(doa.get(3, False)),
        ),
        spatial=SpatialInfo(
            tdoa12_us=int(spatial.get(0, 0)),
            tdoa13_us=int(spatial.get(1, 0)),
            tdoa14_us=int(spatial.get(2, 0)),
            residual_us=int(spatial.get(3, 0)),
            confidence_u8=int(spatial.get(4, 0)),
            geometry_id=int(spatial.get(5, 0)),
            tdoa_valid=bool(spatial_flags & 0x01),
            direction_valid=bool(spatial_flags & 0x02),
        ),
        power=PowerStatus(
            battery_pct=int(status.get(0, 0)),
            battery_mv=int(status.get(1, 0)),
            solar_mv=int(status.get(2, 0)),
            temperature_c10=int(status.get(3, 200)),
            battery_bus_mv=int(status[9]) if 9 in status else None,
            battery_current_ma=int(status[10]) if 10 in status else None,
            battery_power_mw=int(status[11]) if 11 in status else None,
            monitor_status=int(status[12]) if 12 in status else None,
        ),
        route=RouteStatus(
            transport=_ROUTE.get(int(status.get(4, 5)), "TEST"),
            hop_count=int(status.get(5, 0)),
            rssi_dbm=int(status[6]) if 6 in status else None,
            snr_db10=int(status[7]) if 7 in status else None,
            gateway_id=int(status[8]) if 8 in status else None,
        ),
        detector_profile=_PROFILE.get(int(payload.get(10, 0)), "generic"),
        sample_rate_hz=int(payload.get(11, 32000)),
    )


def decode_heartbeat_obj(obj: Any) -> HeartbeatMessage:
    if not isinstance(obj, dict):
        raise ValueError("compact heartbeat must be a CBOR map")
    schema_ver = int(obj.get(0, -1))
    if schema_ver not in _SUPPORTED_HEARTBEAT_SCHEMAS:
        raise ValueError(f"unsupported compact heartbeat schema: {schema_ver}")
    if int(obj.get(1, -1)) != _MSG_HEARTBEAT:
        raise ValueError("unsupported compact heartbeat message type")

    station = _as_map(obj.get(4))
    gnss = _as_map(obj.get(5))
    power = _as_map(obj.get(6))
    route = _as_map(obj.get(7))
    cellular = _as_map(obj.get(12))
    detector = _as_map(obj.get(13)) if schema_ver >= 2 and 13 in obj else None
    if not cellular:
        raise ValueError("compact heartbeat requires cellular telemetry")
    if cellular.get(11) is not True:
        raise ValueError("compact cellular settings must be valid")
    apn_source = _APN_SOURCE.get(_integer_field(cellular, 10, "APN source"))
    if apn_source is None:
        raise ValueError("unsupported compact APN source")

    return HeartbeatMessage(
        station_id=int(obj.get(2, 0)),
        time_us=int(obj.get(3, 0)),
        station=StationPosition(
            lat_e7=int(station.get(0, 0)),
            lon_e7=int(station.get(1, 0)),
            alt_dm=int(station.get(2, 0)),
            pos_accuracy_m=float(station.get(3, 20)),
            altitude_source=_ALTITUDE_SOURCE.get(int(station.get(4, 2)), "unknown"),
            position_source=_POSITION_SOURCE.get(int(station.get(5, 0)), "gnss_live"),
        ),
        gnss=GnssStatus(
            fix_type=int(gnss.get(0, 0)),
            satellites=int(gnss.get(1, 0)),
            hdop_x100=int(gnss.get(2, 9999)),
            pps_ok=bool(gnss.get(3, False)),
            expected_time_error_us=int(gnss.get(4, 1_000_000)),
            jam=bool(gnss.get(5, False)),
            spoof=bool(gnss.get(6, False)),
            position_delta_m=int(gnss.get(7, 0)),
            position_warn=bool(gnss.get(8, False)),
            position_suspect=bool(gnss.get(9, False)),
            time_suspect=bool(gnss.get(10, False)),
            time_holdover=bool(gnss.get(11, False)),
            position_trust=_POSITION_TRUST.get(int(gnss.get(12, 0)), "UNCONFIGURED"),
            time_trust=_TIME_TRUST.get(int(gnss.get(13, 0)), "UNKNOWN"),
        ),
        power=PowerStatus(
            battery_pct=int(power.get(0, 0)),
            battery_mv=int(power.get(1, 0)),
            solar_mv=int(power.get(2, 0)),
            temperature_c10=int(power.get(3, 200)),
            battery_bus_mv=int(power.get(4, 0)),
            battery_current_ma=int(power.get(5, 0)),
            battery_power_mw=int(power.get(6, 0)),
            monitor_status=int(power.get(7, 255)),
        ),
        route=RouteStatus(
            transport=_ROUTE.get(int(route.get(0, 5)), "TEST"),
            hop_count=int(route.get(1, 0)),
            rssi_dbm=int(route.get(2, 0)),
            snr_db10=int(route.get(3, 0)),
            gateway_id=int(route.get(4, 0)),
        ),
        firmware_ver=_text_field(obj, 8, "firmware version"),
        model_ver=_text_field(obj, 9, "model version"),
        hardware_rev=_text_field(obj, 10, "hardware revision"),
        self_test_ok=bool(obj.get(11, False)),
        cellular=CellularTelemetry(
            imsi=_text_field(cellular, 0, "IMSI"),
            iccid=_text_field(cellular, 1, "ICCID"),
            home_plmn=_text_field(cellular, 2, "home PLMN"),
            registered_operator=_text_field(cellular, 3, "registered operator"),
            apn=_text_field(cellular, 4, "APN"),
            local_address=_text_field(cellular, 5, "local address"),
            gateway=_text_field(cellular, 6, "gateway"),
            primary_dns=_text_field(cellular, 7, "primary DNS"),
            secondary_dns=_text_field(cellular, 8, "secondary DNS"),
            access_technology=_integer_field(cellular, 9, "access technology"),
            apn_source=apn_source,
            settings_valid=True,
        ),
        detector=None if detector is None else DetectorHealth(
            boot_id=_integer_field(detector, 0, "boot_id"),
            uptime_s=int(detector.get(1, 0)),
            windows=int(detector.get(2, 0)),
            windows_dropped=int(detector.get(3, 0)),
            confirmed_windows=int(detector.get(4, 0)),
            suspect_windows=int(detector.get(5, 0)),
            engine_windows=int(detector.get(6, 0)),
            events_emitted=int(detector.get(7, 0)),
            events_refused=int(detector.get(8, 0)),
            outbox_pending=int(detector.get(9, 0)),
            window_max_ms=int(detector.get(10, 0)),
            presence_level=_PRESENCE_LEVEL.get(int(detector.get(11, 0)), "NONE"),
            reset_cause=_RESET_CAUSE.get(int(detector.get(12, 0)), "UNKNOWN"),
            watchdog_missed_tasks=int(detector.get(13, 0)),
            params_version=int(detector.get(14, 0)),
            selftest_failed_tests=int(detector.get(15, 0)),
            command_key_id=_key_id_hex(detector.get(16, 0)),
            command_next_key_id=_key_id_hex(detector.get(17, 0)),
            fw_version=int(detector.get(18, 0)),
            fw_state=_FW_STATE.get(int(detector.get(19, 0)), "IDLE"),
            fw_other_version=int(detector.get(20, 0)),
            net_config_version=int(detector.get(21, 0)),
            net_state=_NET_STATE.get(int(detector.get(22, 0)), "STABLE"),
            net_failed_version=int(detector.get(23, 0)),
        ),
    )


def decode_detection_cbor(raw: bytes) -> DetectionMessage:
    return decode_detection_obj(decode_cbor(raw))


def decode_heartbeat_cbor(raw: bytes) -> HeartbeatMessage:
    return decode_heartbeat_obj(decode_cbor(raw))
