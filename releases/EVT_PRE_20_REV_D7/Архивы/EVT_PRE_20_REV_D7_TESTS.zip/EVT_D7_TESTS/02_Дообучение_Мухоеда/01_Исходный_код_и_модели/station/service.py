"""Ingestion, correlation and tracking service."""
from __future__ import annotations
import math, time, uuid, asyncio, logging
from collections import defaultdict
import numpy as np
from station.schemas import DetectionMessage, SystemEvent, TargetEstimate
from station.store import EventStore
from fusion.solver import solve_target
from fusion.geodesy import EnuFrame
from fusion.kalman import ConstantVelocityKalman3D
from station.track_hypotheses import HypothesisTrackFusion
from integration.alert_producer import AlertProducer

log=logging.getLogger(__name__)

class EventBus:
    def __init__(self): self._queues:set[asyncio.Queue]=set()
    def subscribe(self):
        q=asyncio.Queue(maxsize=100); self._queues.add(q); return q
    def unsubscribe(self,q): self._queues.discard(q)
    def publish_nowait(self,item):
        for q in list(self._queues):
            try: q.put_nowait(item)
            except asyncio.QueueFull:
                try: q.get_nowait(); q.put_nowait(item)
                except Exception: pass

class StationFusionService:
    def __init__(self,store:EventStore,correlation_window_s:float=3.0):
        self.store=store; self.window_us=int(correlation_window_s*1e6); self.bus=EventBus(); self.track_filters={}; self.track_frames={}
        self.tracks=HypothesisTrackFusion(store)
        self.alerts=AlertProducer(store)            # output API dioneya.alert/1 (the bridge sets its tenant)
    def _alert(self,handler,*args):
        """The output API never stops ingestion: a failure is logged and the station data stay stored."""
        try: handler(*args)
        except Exception: log.exception('dioneya.alert/1 producer failed')
    @staticmethod
    def _compatible(a:DetectionMessage,b:DetectionMessage)->bool:
        if a.classification.unknown or b.classification.unknown: return True
        if a.classification.class_id==b.classification.class_id: return True
        # Both UAV families may correlate during uncertain first-stage classification.
        return a.classification.class_id in (1,2,3) and b.classification.class_id in (1,2,3)
    def _enforce_configured_station_position(self,d:DetectionMessage)->DetectionMessage:
        hb=self.store.get_station_heartbeat(d.station_id)
        if hb is None or hb.station.position_source!='configured_install': return d
        trusted=hb.station
        same=(d.station.lat_e7==trusted.lat_e7 and d.station.lon_e7==trusted.lon_e7 and d.station.alt_dm==trusted.alt_dm)
        if d.station.position_source=='configured_install' and same: return d
        # A live-GNSS or mismatched position may be retained in diagnostics elsewhere,
        # but must not silently alter fusion/TDOA station geometry.
        gnss=d.gnss.model_copy(update={
            'position_warn':True,
            'position_suspect':True,
            'position_trust':'CONFIGURED_SUSPECT',
        })
        return d.model_copy(update={'station':trusted,'gnss':gnss})
    def ingest(self,d:DetectionMessage)->SystemEvent:
        d=self._enforce_configured_station_position(d)
        self.store.save_detection(d)
        candidates=[x for x in self.store.recent_detections(d.event_time_us,self.window_us) if self._compatible(d,x)]
        # One best detection per station, closest to current event time.
        by_station={}
        for x in candidates:
            old=by_station.get(x.station_id)
            if old is None or abs(x.event_time_us-d.event_time_us)<abs(old.event_time_us-d.event_time_us): by_station[x.station_id]=x
        grouped=list(by_station.values())
        is_alert=len(grouped)>=2
        target=solve_target(grouped) if is_alert else TargetEstimate()
        conf=float(np.mean([x.classification.confidence for x in grouped])) if grouped else d.classification.confidence
        event_type='AIR_ALERT' if is_alert else 'AIR_WARNING'
        # event_id is unique within a station only: the id names the earliest (event_id, station) pair of the group
        first=min(((x.event_id,x.station_id) for x in grouped),default=(d.event_id,d.station_id))
        sid=f"{event_type}-{first[0]:016x}-{first[1]}"
        if is_alert and target.lat is not None:
            target=self._track(sid,target,grouped)
        e=SystemEvent(system_event_id=sid,event_type=event_type,created_time_us=max(x.event_time_us for x in grouped),source_event_ids=[x.event_id for x in grouped],source_station_ids=[x.station_id for x in grouped],classification_label=self._label(grouped),confidence=conf,stations_used=len(grouped),target=target,route_summary=[f"{x.station_id}:{x.route.transport}:{x.route.hop_count}" for x in grouped])
        self.store.save_system_event(e); self.store.link_detections(list(zip(e.source_station_ids,e.source_event_ids)),sid); self.bus.publish_nowait(e.model_dump())
        self._alert(self.alerts.on_event,e,grouped)
        return e
    def ingest_bearings(self,batch)->int:
        """A bearing batch of a tracking window (ICD addendum H): stored, then published live with the system event its
        track belongs to; bearings of two or more stations are fused into the points of one target track."""
        inserted=self.store.save_bearings(batch)
        if inserted:
            self.bus.publish_nowait({'type':'bearings','station_id':batch.station_id,'track_event_id':batch.track_event_id,
                                     'system_event_id':self.store.system_event_of_detection(batch.station_id,batch.track_event_id),
                                     'time_trust':batch.time_trust,'samples':[s.as_dict() for s in batch.samples]})
            tracks=self.tracks.on_batch(batch)         # two or more stations: the fused tracks of its segments, recomputed
            for track in tracks:
                if track['last'] is not None: self.bus.publish_nowait({'type':'track',**track})
            self._alert(self.alerts.on_bearings,batch)   # a line from the station while no fused track carries it
            for track in tracks: self._alert(self.alerts.on_track,track)
        return inserted
    @staticmethod
    def _label(dets):
        if not dets:return 'UNKNOWN'
        return max(dets,key=lambda x:x.classification.confidence).classification.label
    def _track(self,key:str,target:TargetEstimate,dets:list[DetectionMessage])->TargetEstimate:
        # Association key is broad class + local area, not system event ID.
        cls=self._label(dets); station0=dets[0].station; track_key=f"{cls}:{round(station0.lat,2)}:{round(station0.lon,2)}"
        frame=self.track_frames.get(track_key)
        if frame is None:
            frame=EnuFrame(target.lat,target.lon,target.alt_msl_m or 0.0); self.track_frames[track_key]=frame; self.track_filters[track_key]=ConstantVelocityKalman3D()
        pos=frame.to_enu(target.lat,target.lon,target.alt_msl_m or frame.alt0)
        state=self.track_filters[track_key].update(pos,max(d.event_time_us for d in dets)*1e-6,target.horizontal_error_m or 100.0)
        lat,lon,alt=frame.to_geodetic(*state[:3]); vx,vy,vz=state[3:]
        speed=float(math.hypot(vx,vy)); course=(math.degrees(math.atan2(vx,vy))+360.0)%360.0 if speed>0.05 else 0.0
        return target.model_copy(update={'lat':lat,'lon':lon,'alt_msl_m':alt,'vx_east_mps':float(vx),'vy_north_mps':float(vy),'vz_up_mps':float(vz),'speed_mps':speed,'course_deg':course})
