from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app import app
from station.router import store

client=TestClient(app)

def det(station_id,event_id,t_us,lat,lon,az):
    return {
      'schema_ver':1,'station_id':station_id,'seq_no':event_id,'boot_id':1,'event_id':event_id,'event_time_us':t_us,
      'station':{'lat_e7':int(lat*1e7),'lon_e7':int(lon*1e7),'alt_dm':1000},
      'gnss':{'fix_type':3,'satellites':12,'hdop_x100':80,'pps_ok':True,'expected_time_error_us':80},
      'classification':{'class_id':1,'label':'FP-1','confidence_u8':230,'unknown':False},
      'features':[0.0]*43,'doa':{'azimuth_cdeg':int(az*100),'elevation_cdeg':1000,'sigma_cdeg':500,'valid':True},
      'power':{'battery_pct':80,'battery_mv':13000,'solar_mv':17000,'temperature_c10':200},'route':{'transport':'TEST','hop_count':0}
    }

def test_station_http_ingress_is_disabled_by_default(monkeypatch):
    monkeypatch.delenv('ZS_STATION_HTTP_INSECURE_BENCH',raising=False)
    payload=det(9099,9099001,2_000_000_000_000_000,55.0,37.0,45.0)
    response=client.post('/api/v1/stations/9099/detection',json=payload)
    assert response.status_code==403
    assert 'use mutual-TLS MQTT in production' in response.json()['detail']


@pytest.mark.parametrize('value',['true','yes','on','0',''])
def test_station_http_ingress_rejects_ambiguous_opt_in(monkeypatch,value):
    monkeypatch.setenv('ZS_STATION_HTTP_INSECURE_BENCH',value)
    response=client.get('/api/v1/stations/9099/commands/poll')
    assert response.status_code==403


def test_warning_then_alert(tmp_path,insecure_station_http_bench):
    # Unique IDs avoid collisions with persistent local DB from other tests.
    t=2_000_000_000_000_000
    a=client.post('/api/v1/stations/9001/detection',json=det(9001,9001001,t,55.0,37.0,45.0)); assert a.status_code==200; assert a.json()['event_type']=='AIR_WARNING'
    b=client.post('/api/v1/stations/9002/detection',json=det(9002,9002001,t+20000,55.0,37.02,315.0)); assert b.status_code==200; assert b.json()['event_type']=='AIR_ALERT'; assert b.json()['stations_used']>=2

def test_feature_count_validation(insecure_station_http_bench):
    d=det(9003,9003001,2_100_000_000_000_000,55.1,37.1,0); d['features']=[1.0]
    r=client.post('/api/v1/stations/9003/detection',json=d); assert r.status_code==422

def test_feature_update_warms_up_without_hard_type_lock(insecure_station_http_bench):
    payload={
        'schema_ver':1,'station_id':9010,'seq_no':1,'boot_id':1,'event_id':9010001,
        'event_time_us':2_200_000_000_000_000,'features':[0.0]*43,'detector_profile':'piston'
    }
    r=client.post('/api/v1/stations/9010/events/9010001/features',json=payload)
    assert r.status_code==200
    body=r.json()
    assert body['status']=='warming_up'
    assert body['type_lock_allowed'] is False
    assert body['evidence_windows']==1
    assert body['required_windows']==4
    assert body['max_windows']==8
    assert body['hierarchical_label']=='UNKNOWN'

def test_http_heartbeat_rejects_full_cellular_identity(insecure_station_http_bench):
    payload={
        'station_id':9020,'time_us':1,
        'station':{'lat_e7':0,'lon_e7':0,'alt_dm':0},
        'cellular':{
            'imsi':'250011234567890','iccid':'89701012345678901234',
            'apn':'network.apn','local_address':'10.10.0.2',
            'gateway':'10.10.0.1','primary_dns':'1.1.1.1',
            'apn_source':'NETWORK','settings_valid':True,
        },
    }
    response=client.post('/api/v1/stations/9020/heartbeat',json=payload)
    assert response.status_code==400
    assert 'mutual-TLS MQTT status' in response.json()['detail']


def test_bench_http_ack_is_bound_to_command_station(insecure_station_http_bench):
    command=store.create_command(9030,'CMD_REQUEST_AUDIO',{'event_id':9030001})
    wrong=client.post(f'/api/v1/stations/9031/commands/{command.command_id}/ack')
    assert wrong.status_code==409
    accepted=client.post(f'/api/v1/stations/9030/commands/{command.command_id}/ack')
    assert accepted.status_code==200 and accepted.json()['status']=='acked'
    duplicate=client.post(f'/api/v1/stations/9030/commands/{command.command_id}/ack')
    assert duplicate.status_code==200 and duplicate.json()['status']=='duplicate'


def test_audio_request_rejects_station_id_outside_topic_uint32():
    response=client.post('/api/v1/stations/0/audio-request',json={'event_id':1})
    assert response.status_code==400
    assert 'uint32' in response.json()['detail']
