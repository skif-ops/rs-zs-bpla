EVT-PRE-20 REV_D9 — full procurement and production handoff
Дата / Date: 2026-10-16
Привязка исходников / Source binding: 0a7d7803198544dc8f34d08ca4189d8c312fa3ef

RU
Комплект наследует проверенный REV_D8 и добавляет отдельные контролируемые регламенты
по выпуску и жизненному циклу сертификатов, синхронизации времени и доверию координат,
эксплуатации и резервному копированию сервера, а также сводный реестр инструкций.
PCB-MAIN 8L, PCB-PWR 4L и PCB-MIC 2L сохраняются без изменения. KiCad не включён в основной и Altium архивы;
исходники KiCad сохранены в Git и истории. Закрытые ключи, keystore и пароли отсутствуют.

Программа EVT состоит из двух групп по 20 станций и одной стендовой станции, всего 41.
Зарезервированы DIO-EVT-001...040 и DIO-EVT-B01. Закупка представлена двумя вариантами:
21 станция (один EVT-20 плюс стендовая) и 41 станция (два EVT-20 плюс стендовая).
Число 21 в форме EOL также встречается как количество открытых критериев и не означает
общий объём программы.

Статус: комплект документов и программных артефактов готов для закупки, EVT-сборки,
заказа прототипов и измерений. Окончательные числовые EOL-пределы, DFM/first article,
полная аппаратная квалификация и производственная блокировка остаются открыты до
измерений собранной DIO-EVT-B01 и последующих станций. Неопределённый обязательный
предел или отсутствующее evidence дают HOLD, а не PASS.

EN
This package inherits the verified REV_D8 handoff and adds controlled procedures for
certificate issuance and lifecycle, time synchronization and position trust, server operations
and backup, plus a complete instruction register. The fixed stackups remain PCB-MAIN 8L,
PCB-PWR 4L and PCB-MIC 2L. KiCad sources are retained
in Git/history and are excluded from the main and Altium factory archives. No private
key, keystore or password is included.

The EVT program has two groups of 20 stations plus one bench station, 41 total, with
DIO-EVT-001...040 and DIO-EVT-B01 reserved. Procurement is provided as two options:
21 stations (one EVT-20 lot plus the bench) and 41 stations (two EVT-20 lots plus the
bench). The value 21 in the EOL form is also the open-criteria count and is not the
program station quantity.

The document and software handoff is ready for procurement, EVT assembly, prototype
ordering and measurement. Final numeric EOL limits, vendor DFM/first article, full
hardware qualification and production firmware locking remain open until measurements
on assembled DIO-EVT-B01/stations are completed. An undefined mandatory limit or
missing evidence produces HOLD.
