from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

TOOLING_ROOT = Path(__file__).resolve().parents[1]
if str(TOOLING_ROOT) not in sys.path:
    sys.path.insert(0, str(TOOLING_ROOT))

from spatial_evt_analyzer import analyze, init_templates, load_json


SCHEMA_PATH = TOOLING_ROOT / "spatial_evt_schema.json"


def rewrite(path: Path, transform) -> None:
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        rows = [transform(dict(row)) for row in reader]
        fields = reader.fieldnames
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def make_complete(folder: Path, origin: str = "SYNTHETIC_NOT_HARDWARE") -> dict:
    schema = load_json(SCHEMA_PATH)
    init_templates(folder, schema)
    passport_path = folder / "passport.json"
    passport = json.loads(passport_path.read_text(encoding="utf-8"))
    passport.update({
        "data_origin": origin,
        "station_id": "TEST-001",
        "serial_number": "SYN-001",
        "test_date": "2026-09-04",
        "operator": "TEST",
        "test_location": "LAB-01",
        "firmware_version": "v0.5-test",
        "firmware_commit_sha": "1" * 40,
        "dsp_version": "v0.5-test",
        "protocol_version": "1.3",
        "model_version": "v0.8",
        "mcu": "STM32U585",
        "core_clock_hz": 160000000,
        "compiler": "arm-none-eabi-gcc",
        "compiler_version": "13.2",
        "compiler_flags": "-O2",
        "build_type": "Release",
        "flash_wait_states": 5,
        "cache_settings": "I=ON,D=ON",
        "pdm_clock_hz": 3072000,
        "pcm_fs_hz": 32000,
        "channel_map": "M1,M2,M3,M4",
        "temperature_c": 20.0,
        "source_positioner": "POS-01",
        "source_trace_directory": "traces/run-001",
        "source_trace_sha256": "0" * 64,
        "analyzer_version": "0.7",
    })
    passport_path.write_text(json.dumps(passport, indent=2), encoding="utf-8")
    coords = {"M1":(-60,-34.641,0),"M2":(60,-34.641,0),"M3":(0,69.282,0),"M4":(0,0,150)}
    rewrite(folder / "geometry.csv", lambda r: {**r, "x_mm":coords[r["mic"]][0], "y_mm":coords[r["mic"]][1], "z_mm":coords[r["mic"]][2]})
    rewrite(folder / "calibration.csv", lambda r: {**r, "residual12_us":"5", "residual13_us":"-4", "residual14_us":"8", "valid":"1", "dma_overrun":"0"})
    rewrite(folder / "directions.csv", lambda r: {**r, "n_repeats":"10", "valid_rate":"0.98", "az_median_deg":r["az_true_deg"], "el_median_deg":r["el_true_deg"], "az_p95_deg":"3", "el_p95_deg":"4", "impossible_tdoa_accepted":"0"})
    durations = {"WIND_10MS_NO_TARGET":"10", "ROAD_NO_TARGET":"30", "RAIN_NO_TARGET":"15", "TARGET_PLUS_ROAD":"5"}
    def fill_interference(row):
        values = {**row, "duration_min":durations[row["scenario"]], "windows":"1000", "spatial_valid":"0", "locks_ge_5s":"0", "air_alert":"0"}
        if row["scenario"] == "WIND_10MS_NO_TARGET":
            values["wind_speed_mps"] = "10"
        if row["scenario"] == "RAIN_NO_TARGET":
            values["drainage_ok"] = "1"
            values["mic_faults"] = "0"
        if row["scenario"] == "TARGET_PLUS_ROAD":
            values.update({"target_directions":"24", "target_valid_rate":"0.98", "target_az_median_error_deg":"5", "target_el_median_error_deg":"7", "impossible_tdoa_accepted":"0"})
        return values
    rewrite(folder / "interference.csv", fill_interference)
    rewrite(folder / "resources.csv", lambda r: {**r, "p99_total_us":"200000", "total_calls":"1000", "dma_overrun":"0", "sram_total_b":"786432", "static_b":"220000", "stack_peak_b":"50000", "heap_peak_b":"30000", "other_reserved_b":"10000"})
    return schema


class AnalyzerTests(unittest.TestCase):
    def test_complete_synthetic_is_not_hardware(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder)
            result = analyze(folder, schema)
            self.assertEqual(result["overall_status"], "SYNTHETIC_NOT_HARDWARE")
            self.assertTrue(all(g["status"] == "PASS" for g in result["gates"]))
            self.assertEqual(result["traceability"]["status"], "PASS")

    def test_complete_hardware_can_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            result = analyze(folder, schema)
            self.assertEqual(result["overall_status"], "PASS")
            self.assertEqual(result["traceability"]["status"], "PASS")

    def test_bad_direction_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            changed = False

            def corrupt(row):
                nonlocal changed
                if not changed:
                    row["az_median_deg"] = "90"
                    changed = True
                return row

            rewrite(folder / "directions.csv", corrupt)
            result = analyze(folder, schema)
            self.assertEqual(result["overall_status"], "FAIL")
            gate = next(g for g in result["gates"] if g["gate_id"] == "SP-3P1-003")
            self.assertEqual(gate["status"], "FAIL")

    def test_missing_files_are_not_run(self):
        with tempfile.TemporaryDirectory() as directory:
            schema = load_json(SCHEMA_PATH)
            result = analyze(Path(directory), schema)
            self.assertEqual(result["overall_status"], "NOT RUN")

    def test_blank_initialized_templates_are_not_run(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = load_json(SCHEMA_PATH)
            init_templates(folder, schema)
            result = analyze(folder, schema)
            self.assertEqual(result["overall_status"], "NOT RUN")
            self.assertTrue(all(g["status"] == "NOT RUN" for g in result["gates"]))
            self.assertEqual(result["traceability"]["status"], "NOT RUN")

    def test_partial_passport_fails_traceability(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            passport_path = folder / "passport.json"
            passport = json.loads(passport_path.read_text(encoding="utf-8"))
            passport["compiler_version"] = ""
            passport_path.write_text(json.dumps(passport), encoding="utf-8")
            result = analyze(folder, schema)
            self.assertEqual(result["overall_status"], "FAIL")
            self.assertEqual(result["traceability"]["status"], "FAIL")

    def test_bad_traceability_values_fail(self):
        cases = {
            "source_trace_sha256": "not-a-hash",
            "firmware_commit_sha": "not-a-commit",
            "analyzer_version": "0.6",
            "model_version": "v0.7",
            "channel_map": "M1,M3,M2,M4",
            "flash_wait_states": "1.5",
        }
        for field, value in cases.items():
            with self.subTest(field=field), tempfile.TemporaryDirectory() as directory:
                folder = Path(directory)
                schema = make_complete(folder, origin="HARDWARE")
                passport_path = folder / "passport.json"
                passport = json.loads(passport_path.read_text(encoding="utf-8"))
                passport[field] = value
                passport_path.write_text(json.dumps(passport), encoding="utf-8")
                self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_wind_below_10_mps_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "interference.csv", lambda r: {**r, "wind_speed_mps":"9.9"} if r["scenario"] == "WIND_10MS_NO_TARGET" else r)
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_zero_road_windows_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "interference.csv", lambda r: {**r, "windows":"0"} if r["scenario"] == "ROAD_NO_TARGET" else r)
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_rain_drainage_failure_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "interference.csv", lambda r: {**r, "drainage_ok":"0"} if r["scenario"] == "RAIN_NO_TARGET" else r)
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_target_road_requires_24_directions(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "interference.csv", lambda r: {**r, "target_directions":"23"} if r["scenario"] == "TARGET_PLUS_ROAD" else r)
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_duplicate_geometry_microphone_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            path = folder / "geometry.csv"
            with path.open("a", encoding="utf-8", newline="") as fh:
                fh.write("M1,0,0,0\n")
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_non_finite_geometry_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "geometry.csv", lambda r: {**r, "x_mm":"nan"} if r["mic"] == "M1" else r)
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")

    def test_sram_overcommit_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            schema = make_complete(folder, origin="HARDWARE")
            rewrite(folder / "resources.csv", lambda r: {**r, "static_b":"800000"})
            self.assertEqual(analyze(folder, schema)["overall_status"], "FAIL")


if __name__ == "__main__":
    unittest.main()
