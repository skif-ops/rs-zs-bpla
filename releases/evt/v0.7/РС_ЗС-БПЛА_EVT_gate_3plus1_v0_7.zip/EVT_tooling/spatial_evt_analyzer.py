#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


ROOT = Path(__file__).resolve().parent
DEFAULT_SCHEMA = ROOT / "spatial_evt_schema.json"


@dataclass
class Gate:
    gate_id: str
    status: str
    metrics: dict[str, Any]
    reasons: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "gate_id": self.gate_id,
            "status": self.status,
            "metrics": self.metrics,
            "reasons": self.reasons,
        }


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def number(row: dict[str, str], key: str) -> float:
    value = row.get(key, "").strip()
    if not value:
        raise ValueError(f"empty {key}")
    result = float(value.replace(",", "."))
    if not math.isfinite(result):
        raise ValueError(f"non-finite {key}")
    return result


def integer(row: dict[str, str], key: str) -> int:
    value = number(row, key)
    if not value.is_integer():
        raise ValueError(f"non-integer {key}")
    return int(value)


def truth(row: dict[str, str], key: str) -> bool:
    return row.get(key, "").strip().lower() in {"1", "true", "yes", "pass"}


def boolean(row: dict[str, str], key: str) -> bool:
    value = row.get(key, "").strip().lower()
    if value in {"1", "true", "yes", "pass"}:
        return True
    if value in {"0", "false", "no", "fail"}:
        return False
    raise ValueError(f"invalid boolean {key}")


def circular_error(measured: float, expected: float) -> float:
    return abs((measured - expected + 180.0) % 360.0 - 180.0)


def not_run(gate_id: str, reason: str) -> Gate:
    return Gate(gate_id, "NOT RUN", {}, [reason])


def has_any_value(rows: list[dict[str, str]], keys: tuple[str, ...]) -> bool:
    return any(str(row.get(key, "")).strip() for row in rows for key in keys)


def check_geometry(folder: Path) -> Gate:
    rows = read_csv(folder / "geometry.csv")
    if not rows:
        return not_run("SP-3P1-001", "geometry.csv is missing or empty")
    if not has_any_value(rows, ("x_mm", "y_mm", "z_mm")):
        return not_run("SP-3P1-001", "geometry.csv contains no measurements")
    reasons: list[str] = []
    coords: dict[str, tuple[float, float, float]] = {}
    try:
        for row in rows:
            mic = row.get("mic", "").strip()
            if mic:
                if mic in coords:
                    reasons.append(f"duplicate microphone: {mic}")
                coords[mic] = (number(row, "x_mm"), number(row, "y_mm"), number(row, "z_mm"))
    except ValueError as exc:
        reasons.append(str(exc))
    expected = {"M1", "M2", "M3", "M4"}
    missing = sorted(expected - set(coords))
    extra = sorted(set(coords) - expected)
    if missing:
        reasons.append("missing microphones: " + ", ".join(missing))
    if extra:
        reasons.append("unexpected microphones: " + ", ".join(extra))
    baselines: dict[str, float] = {}
    if not missing:
        for a, b in (("M1", "M2"), ("M1", "M3"), ("M1", "M4"), ("M2", "M3"), ("M2", "M4"), ("M3", "M4")):
            baselines[f"{a}-{b}"] = math.dist(coords[a], coords[b])
        if any(value <= 0 for value in baselines.values()):
            reasons.append("one or more microphone baselines are zero")
    return Gate("SP-3P1-001", "FAIL" if reasons else "PASS", {"coordinates": coords, "baselines_mm": baselines}, reasons)


def check_calibration(folder: Path, schema: dict[str, Any]) -> Gate:
    rows = read_csv(folder / "calibration.csv")
    if not rows:
        return not_run("SP-3P1-002", "calibration.csv is missing or empty")
    if not has_any_value(rows, ("residual12_us", "residual13_us", "residual14_us", "valid")):
        return not_run("SP-3P1-002", "calibration.csv contains no measurements")
    t = schema["thresholds"]
    profiles = schema["profiles"]
    reasons: list[str] = []
    metrics: dict[str, Any] = {"profiles": {}}
    unexpected = sorted({r.get("profile", "").strip() for r in rows} - set(profiles))
    if unexpected:
        reasons.append("unexpected profiles: " + ", ".join(unexpected))
    run_ids: set[tuple[str, int]] = set()
    try:
        for row in rows:
            run_id = integer(row, "run_id")
            run_key = (row.get("profile", "").strip(), run_id)
            if run_key in run_ids:
                reasons.append(f"duplicate profile/run_id: {run_key}")
            run_ids.add(run_key)
            boolean(row, "valid")
    except ValueError as exc:
        reasons.append(str(exc))
    for profile in profiles:
        subset = [r for r in rows if r.get("profile", "").strip() == profile]
        valid_rows = [r for r in subset if truth(r, "valid")]
        valid_rate = len(valid_rows) / len(subset) if subset else 0.0
        residuals: list[float] = []
        dma_total = 0
        try:
            for row in subset:
                dma_total += integer(row, "dma_overrun")
            for row in valid_rows:
                residuals.extend(abs(number(row, key)) for key in ("residual12_us", "residual13_us", "residual14_us"))
        except ValueError as exc:
            reasons.append(f"{profile}: {exc}")
        maximum = max(residuals) if residuals else None
        metrics["profiles"][profile] = {
            "windows": len(subset),
            "valid_rate": valid_rate,
            "max_abs_residual_us": maximum,
            "dma_overrun": dma_total,
        }
        if len(subset) < t["min_calibration_windows_per_profile"]:
            reasons.append(f"{profile}: fewer than {t['min_calibration_windows_per_profile']} windows")
        if valid_rate < t["min_valid_rate"]:
            reasons.append(f"{profile}: valid rate {valid_rate:.3f} below threshold")
        if maximum is None or maximum > t["max_residual_delay_us"]:
            reasons.append(f"{profile}: residual delay threshold failed")
        if dma_total > t["max_dma_overrun"]:
            reasons.append(f"{profile}: DMA overrun detected")
    return Gate("SP-3P1-002", "FAIL" if reasons else "PASS", metrics, reasons)


def check_directions(folder: Path, schema: dict[str, Any]) -> Gate:
    rows = read_csv(folder / "directions.csv")
    if not rows:
        return not_run("SP-3P1-003", "directions.csv is missing or empty")
    if not has_any_value(rows, ("n_repeats", "valid_rate", "az_median_deg", "el_median_deg")):
        return not_run("SP-3P1-003", "directions.csv contains no measurements")
    t = schema["thresholds"]
    required = {
        (float(az), float(el), profile)
        for profile in schema["profiles"]
        for el in schema["elevations_deg"]
        for az in schema["azimuths_deg"]
    }
    seen: set[tuple[float, float, str]] = set()
    reasons: list[str] = []
    errors_az: list[float] = []
    errors_el: list[float] = []
    try:
        for row in rows:
            key = (number(row, "az_true_deg"), number(row, "el_true_deg"), row.get("profile", "").strip())
            if key in seen:
                reasons.append(f"duplicate direction/profile configuration: {key}")
            seen.add(key)
            n = integer(row, "n_repeats")
            valid_rate = number(row, "valid_rate")
            az_err = circular_error(number(row, "az_median_deg"), key[0])
            el_err = abs(number(row, "el_median_deg") - key[1])
            errors_az.append(az_err)
            errors_el.append(el_err)
            if not 0.0 <= valid_rate <= 1.0:
                reasons.append(f"{key}: valid rate outside 0..1")
            if n < t["min_repeats_per_direction"]:
                reasons.append(f"{key}: not enough repeats")
            if valid_rate < t["min_valid_rate"]:
                reasons.append(f"{key}: valid rate below threshold")
            if az_err > t["max_median_az_error_deg"]:
                reasons.append(f"{key}: azimuth median error {az_err:.3f}")
            if el_err > t["max_median_el_error_deg"]:
                reasons.append(f"{key}: elevation median error {el_err:.3f}")
            if integer(row, "impossible_tdoa_accepted") != 0:
                reasons.append(f"{key}: physically impossible TDOA accepted")
            if number(row, "az_p95_deg") < 0 or number(row, "el_p95_deg") < 0:
                reasons.append(f"{key}: negative p95 error")
    except ValueError as exc:
        reasons.append(str(exc))
    missing = sorted(required - seen)
    extra = sorted(seen - required)
    if missing:
        reasons.append(f"missing direction/profile configurations: {len(missing)}")
    if extra:
        reasons.append(f"unexpected direction/profile configurations: {len(extra)}")
    metrics = {
        "required_configurations": len(required),
        "seen_configurations": len(seen),
        "max_median_az_error_deg": max(errors_az) if errors_az else None,
        "max_median_el_error_deg": max(errors_el) if errors_el else None,
    }
    return Gate("SP-3P1-003", "FAIL" if reasons else "PASS", metrics, reasons)


def check_interference(folder: Path, schema: dict[str, Any]) -> Gate:
    rows = read_csv(folder / "interference.csv")
    if not rows:
        return not_run("SP-3P1-004", "interference.csv is missing or empty")
    if not has_any_value(rows, ("windows", "spatial_valid", "locks_ge_5s", "air_alert")):
        return not_run("SP-3P1-004", "interference.csv contains no measurements")
    t = schema["thresholds"]
    names = [r.get("scenario", "").strip() for r in rows]
    by_name = {name: row for name, row in zip(names, rows)}
    reasons: list[str] = []
    metrics: dict[str, Any] = {}
    specs = {
        "WIND_10MS_NO_TARGET": 10.0,
        "ROAD_NO_TARGET": 30.0,
        "RAIN_NO_TARGET": 15.0,
        "TARGET_PLUS_ROAD": 0.0,
    }
    duplicates = sorted({name for name in names if names.count(name) > 1})
    unexpected = sorted(set(names) - set(specs))
    if duplicates:
        reasons.append("duplicate scenarios: " + ", ".join(duplicates))
    if unexpected:
        reasons.append("unexpected scenarios: " + ", ".join(unexpected))
    for name, min_duration in specs.items():
        row = by_name.get(name)
        if row is None:
            reasons.append(f"missing scenario {name}")
            continue
        try:
            duration = number(row, "duration_min") if min_duration else float(row.get("duration_min", "0") or 0)
            windows = integer(row, "windows")
            valid = integer(row, "spatial_valid")
            locks = integer(row, "locks_ge_5s")
            alerts = integer(row, "air_alert")
            rate = valid / windows if windows else 1.0
            if windows < t["min_interference_windows"]:
                reasons.append(f"{name}: no measured windows")
            if any(value < 0 for value in (windows, valid, locks, alerts)):
                reasons.append(f"{name}: negative count")
            if valid > windows:
                reasons.append(f"{name}: spatial_valid exceeds windows")
            metrics[name] = {"duration_min": duration, "windows": windows, "valid_rate": rate, "locks_ge_5s": locks, "air_alert": alerts}
            if duration < min_duration:
                reasons.append(f"{name}: duration below minimum")
            if alerts > t["max_air_alerts"]:
                reasons.append(f"{name}: AIR_ALERT detected")
            if name == "WIND_10MS_NO_TARGET" and rate > t["max_wind_spatial_valid_rate"]:
                reasons.append(f"{name}: spatial valid rate above threshold")
            if name == "WIND_10MS_NO_TARGET":
                wind_speed = number(row, "wind_speed_mps")
                metrics[name]["wind_speed_mps"] = wind_speed
                if wind_speed < t["min_wind_speed_mps"]:
                    reasons.append(f"{name}: wind speed below minimum")
            if name == "ROAD_NO_TARGET" and locks > t["max_persistent_locks"]:
                reasons.append(f"{name}: persistent DOA lock detected")
            if name == "RAIN_NO_TARGET":
                drainage_ok = boolean(row, "drainage_ok")
                mic_faults = integer(row, "mic_faults")
                metrics[name].update({"drainage_ok": drainage_ok, "mic_faults": mic_faults})
                if not drainage_ok:
                    reasons.append(f"{name}: drainage check failed")
                if mic_faults != 0:
                    reasons.append(f"{name}: microphone faults detected")
            if name == "TARGET_PLUS_ROAD":
                target_directions = integer(row, "target_directions")
                target_valid_rate = number(row, "target_valid_rate")
                az_error = number(row, "target_az_median_error_deg")
                el_error = number(row, "target_el_median_error_deg")
                impossible = integer(row, "impossible_tdoa_accepted")
                metrics[name].update({
                    "target_directions": target_directions,
                    "target_valid_rate": target_valid_rate,
                    "target_az_median_error_deg": az_error,
                    "target_el_median_error_deg": el_error,
                    "impossible_tdoa_accepted": impossible,
                })
                if target_directions < t["min_target_road_directions"]:
                    reasons.append(f"{name}: fewer than required target directions")
                if not 0.0 <= target_valid_rate <= 1.0 or target_valid_rate < t["min_valid_rate"]:
                    reasons.append(f"{name}: target valid rate below threshold")
                if az_error > t["max_median_az_error_deg"]:
                    reasons.append(f"{name}: target azimuth error above threshold")
                if el_error > t["max_median_el_error_deg"]:
                    reasons.append(f"{name}: target elevation error above threshold")
                if impossible != 0:
                    reasons.append(f"{name}: physically impossible TDOA accepted")
        except ValueError as exc:
            reasons.append(f"{name}: {exc}")
    return Gate("SP-3P1-004", "FAIL" if reasons else "PASS", metrics, reasons)


def check_resources(folder: Path, schema: dict[str, Any]) -> Gate:
    rows = read_csv(folder / "resources.csv")
    if not rows:
        return not_run("SP-3P1-005", "resources.csv is missing or empty")
    if not has_any_value(rows, ("p99_total_us", "total_calls", "sram_total_b")):
        return not_run("SP-3P1-005", "resources.csv contains no measurements")
    t = schema["thresholds"]
    row = rows[0]
    reasons: list[str] = []
    metrics: dict[str, Any] = {}
    if len(rows) != 1:
        reasons.append("resources.csv must contain exactly one summary row")
    try:
        p99 = number(row, "p99_total_us")
        calls = integer(row, "total_calls")
        dma = integer(row, "dma_overrun")
        total = number(row, "sram_total_b")
        used = sum(number(row, key) for key in ("static_b", "stack_peak_b", "heap_peak_b", "other_reserved_b"))
        reserve = (total - used) / total if total > 0 else -1.0
        cpu_load = p99 / t["hop_period_us"]
        metrics = {"p99_total_us": p99, "cpu_load": cpu_load, "total_calls": calls, "dma_overrun": dma, "sram_reserve": reserve}
        if p99 <= 0 or calls < 0 or dma < 0 or total <= 0 or used < 0:
            reasons.append("resource counters must be finite and non-negative, with positive timing and SRAM total")
        if used > total:
            reasons.append("reported SRAM use exceeds SRAM total")
        if cpu_load > t["max_cpu_load"]:
            reasons.append("CPU load above threshold")
        if calls < t["min_profile_calls"]:
            reasons.append("profile call count below threshold")
        if dma > t["max_dma_overrun"]:
            reasons.append("DMA overrun detected")
        if reserve < t["min_sram_reserve"]:
            reasons.append("SRAM reserve below threshold")
    except ValueError as exc:
        reasons.append(str(exc))
    return Gate("SP-3P1-005", "FAIL" if reasons else "PASS", metrics, reasons)


def init_templates(folder: Path, schema: dict[str, Any]) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    passport = {
        "schema_version": schema["schema_version"],
        "data_origin": "HARDWARE",
        "station_id": "",
        "serial_number": "",
        "test_date": "",
        "operator": "",
        "test_location": "",
        "geometry_id": schema["geometry_id"],
        "firmware_version": "",
        "firmware_commit_sha": "",
        "dsp_version": "",
        "protocol_version": "1.3",
        "model_version": "v0.8",
        "mcu": "STM32U585",
        "core_clock_hz": "",
        "compiler": "",
        "compiler_version": "",
        "compiler_flags": "",
        "build_type": "Release",
        "flash_wait_states": "",
        "cache_settings": "",
        "pdm_clock_hz": "",
        "pcm_fs_hz": schema["sample_rate_hz"],
        "channel_map": "M1,M2,M3,M4",
        "temperature_c": "",
        "source_positioner": "",
        "source_trace_directory": "",
        "source_trace_sha256": "",
        "analyzer_version": schema["schema_version"]
    }
    (folder / "passport.json").write_text(json.dumps(passport, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_csv(folder / "geometry.csv", ["mic", "x_mm", "y_mm", "z_mm"], [
        {"mic": mic, "x_mm": "", "y_mm": "", "z_mm": ""} for mic in ("M1", "M2", "M3", "M4")
    ])
    write_csv(folder / "calibration.csv", ["run_id", "profile", "residual12_us", "residual13_us", "residual14_us", "valid", "dma_overrun"], [
        {"run_id": idx + 1, "profile": profile, "residual12_us": "", "residual13_us": "", "residual14_us": "", "valid": "", "dma_overrun": ""}
        for profile in schema["profiles"] for idx in range(schema["thresholds"]["min_calibration_windows_per_profile"])
    ])
    write_csv(folder / "directions.csv", ["case_id", "az_true_deg", "el_true_deg", "profile", "n_repeats", "valid_rate", "az_median_deg", "el_median_deg", "az_p95_deg", "el_p95_deg", "impossible_tdoa_accepted"], [
        {"case_id": idx + 1, "az_true_deg": az, "el_true_deg": el, "profile": profile, "n_repeats": "", "valid_rate": "", "az_median_deg": "", "el_median_deg": "", "az_p95_deg": "", "el_p95_deg": "", "impossible_tdoa_accepted": ""}
        for idx, (profile, el, az) in enumerate((p, e, a) for p in schema["profiles"] for e in schema["elevations_deg"] for a in schema["azimuths_deg"])
    ])
    write_csv(folder / "interference.csv", ["scenario", "duration_min", "windows", "spatial_valid", "locks_ge_5s", "air_alert", "wind_speed_mps", "drainage_ok", "mic_faults", "target_directions", "target_valid_rate", "target_az_median_error_deg", "target_el_median_error_deg", "impossible_tdoa_accepted"], [
        {"scenario": name, "duration_min": "", "windows": "", "spatial_valid": "", "locks_ge_5s": "", "air_alert": "", "wind_speed_mps": "", "drainage_ok": "", "mic_faults": "", "target_directions": "", "target_valid_rate": "", "target_az_median_error_deg": "", "target_el_median_error_deg": "", "impossible_tdoa_accepted": ""}
        for name in ("WIND_10MS_NO_TARGET", "ROAD_NO_TARGET", "RAIN_NO_TARGET", "TARGET_PLUS_ROAD")
    ])
    write_csv(folder / "resources.csv", ["p99_total_us", "total_calls", "dma_overrun", "sram_total_b", "static_b", "stack_peak_b", "heap_peak_b", "other_reserved_b"], [{}])


def check_traceability(passport: dict[str, Any], schema: dict[str, Any]) -> Gate:
    required = tuple(schema["required_passport_fields"])
    user_fields = ("station_id", "serial_number", "test_date", "operator", "test_location", "firmware_version")
    if not any(str(passport.get(key, "")).strip() for key in user_fields):
        return not_run("TRACEABILITY", "hardware run passport is not filled")
    missing = [key for key in required if not str(passport.get(key, "")).strip()]
    reasons = ["missing passport fields: " + ", ".join(missing)] if missing else []
    try:
        if str(passport.get("schema_version")) != str(schema["schema_version"]):
            reasons.append("passport schema_version does not match analyzer schema")
        if int(passport.get("geometry_id")) != int(schema["geometry_id"]):
            reasons.append("passport geometry_id does not match schema")
        if str(passport.get("protocol_version")) != "1.3":
            reasons.append("protocol_version must be 1.3 for this EVT release")
        if str(passport.get("model_version")) != "v0.8":
            reasons.append("model_version must be v0.8 for this EVT release")
        if str(passport.get("analyzer_version")) != str(schema["schema_version"]):
            reasons.append("analyzer_version does not match analyzer schema")
        if str(passport.get("mcu")) != "STM32U585":
            reasons.append("hardware gate requires STM32U585")
        if str(passport.get("build_type")) != "Release":
            reasons.append("build_type must be Release")
        if int(passport.get("pcm_fs_hz")) != int(schema["sample_rate_hz"]):
            reasons.append("pcm_fs_hz does not match schema")
        core_clock = float(passport.get("core_clock_hz"))
        pdm_clock = float(passport.get("pdm_clock_hz"))
        if not math.isfinite(core_clock) or not math.isfinite(pdm_clock) or core_clock <= 0 or pdm_clock <= 0:
            reasons.append("clock frequencies must be positive")
        flash_wait_states = float(passport.get("flash_wait_states"))
        if not math.isfinite(flash_wait_states) or flash_wait_states < 0 or not flash_wait_states.is_integer():
            reasons.append("flash_wait_states must be a non-negative integer")
        if not math.isfinite(float(str(passport.get("temperature_c")).replace(",", "."))):
            reasons.append("temperature_c must be finite")
    except (TypeError, ValueError):
        reasons.append("invalid typed value in passport")
    sha = str(passport.get("source_trace_sha256", "")).strip()
    if sha and re.fullmatch(r"[0-9a-fA-F]{64}", sha) is None:
        reasons.append("source_trace_sha256 must contain 64 hexadecimal characters")
    firmware_sha = str(passport.get("firmware_commit_sha", "")).strip()
    if firmware_sha and re.fullmatch(r"[0-9a-fA-F]{7,64}", firmware_sha) is None:
        reasons.append("firmware_commit_sha must contain 7 to 64 hexadecimal characters")
    channel_map = re.sub(r"\s+", "", str(passport.get("channel_map", "")))
    if channel_map and channel_map != "M1,M2,M3,M4":
        reasons.append("channel_map must be M1,M2,M3,M4")
    return Gate("TRACEABILITY", "FAIL" if reasons else "PASS", {"required_fields": len(required)}, reasons)


def analyze(folder: Path, schema: dict[str, Any]) -> dict[str, Any]:
    passport_path = folder / "passport.json"
    if not passport_path.exists():
        origin = "UNKNOWN"
        passport: dict[str, Any] = {}
    else:
        passport = load_json(passport_path)
        origin = str(passport.get("data_origin", "UNKNOWN"))
    checks: list[Callable[[], Gate]] = [
        lambda: check_geometry(folder),
        lambda: check_calibration(folder, schema),
        lambda: check_directions(folder, schema),
        lambda: check_interference(folder, schema),
        lambda: check_resources(folder, schema),
    ]
    gates = [check() for check in checks]
    traceability = check_traceability(passport, schema)
    statuses = {gate.status for gate in gates}
    if "FAIL" in statuses or traceability.status == "FAIL":
        overall = "FAIL"
    elif "NOT RUN" in statuses or traceability.status == "NOT RUN":
        overall = "NOT RUN"
    elif origin != "HARDWARE":
        overall = "SYNTHETIC_NOT_HARDWARE"
    else:
        overall = "PASS"
    return {
        "schema_version": schema["schema_version"],
        "data_origin": origin,
        "overall_status": overall,
        "traceability": traceability.as_dict(),
        "gates": [gate.as_dict() for gate in gates],
    }


def report_markdown(result: dict[str, Any]) -> str:
    lines = [
        "# Spatial EVT hardware gate report",
        "",
        f"- Schema: {result['schema_version']}",
        f"- Data origin: {result['data_origin']}",
        f"- Overall status: {result['overall_status']}",
        "",
        "| Gate | Status | Reasons |",
        "|---|---|---|",
    ]
    for gate in result["gates"]:
        reasons = "; ".join(gate["reasons"]) or "none"
        lines.append(f"| {gate['gate_id']} | {gate['status']} | {reasons} |")
    trace = result["traceability"]
    trace_reasons = "; ".join(trace["reasons"]) or "none"
    lines.append(f"| {trace['gate_id']} | {trace['status']} | {trace_reasons} |")
    lines.extend(["", "Hardware PASS is valid only for data_origin=HARDWARE with complete traceability.", ""])
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate ZS-BPLA 3+1 EVT hardware gate results")
    parser.add_argument("results_dir", type=Path)
    parser.add_argument("--schema", type=Path, default=DEFAULT_SCHEMA)
    parser.add_argument("--init", action="store_true", help="create blank result templates")
    parser.add_argument("--out", type=Path, help="output directory for reports")
    args = parser.parse_args(argv)
    schema = load_json(args.schema)
    if args.init:
        init_templates(args.results_dir, schema)
        return 0
    result = analyze(args.results_dir, schema)
    out = args.out or args.results_dir
    out.mkdir(parents=True, exist_ok=True)
    (out / "hardware_gate_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "hardware_gate_report.md").write_text(report_markdown(result), encoding="utf-8")
    print(result["overall_status"])
    if result["overall_status"] == "PASS":
        return 0
    if result["overall_status"] in {"NOT RUN", "SYNTHETIC_NOT_HARDWARE"}:
        return 2
    return 1


if __name__ == "__main__":
    sys.exit(main())
