# ЗС-БПЛА firmware, EVT-PRE-20

Текущий каталог содержит переносимое C11-ядро: типы событий, compact CBOR, DSP, архивирование, state machines BG95/LoRa, GNSS parsing и host-тесты.

Целевой контроллер предсерии: `STM32U585VIT6Q`, LQFP100. Упоминания STM32U585ZI и платы WeAct относятся к предыдущим этапам и не являются target EVT-PRE-20.

Текущий подписанный кандидат: `EVT_PRE_20_RELEASE_CANDIDATE_2026101601`. Версия STM32: `2026101601`; версия nRF52840: `0.1.0+2026101601`; Android: `0.1.0-evt.20261016` (`versionCode 2026101601`). Статус: `READY FOR EVT BUILD AND B01 MEASUREMENTS / HARDWARE QUALIFICATION PENDING`. Полная история и хеши образов находятся в [`RELEASE_NOTES.md`](RELEASE_NOTES.md).

## Что уже проверяется

```sh
cmake -S firmware -B firmware/build -DCMAKE_BUILD_TYPE=Release
cmake --build firmware/build --parallel
ctest --test-dir firmware/build --output-on-failure
```

Host PASS подтверждает переносимое ядро, но не заменяет аппаратную проверку. Выпускной архив содержит подписанные образы STM32 и nRF52840, манифесты и контрольные суммы. Для прошивки используется только образ из выпущенного архива; произвольный BIN/HEX из каталога сборки применять нельзя.

## Что остаётся до завершения аппаратных испытаний

- SWD, BOOT0, system-memory recovery и read-back option bytes;
- A/B swap, trial confirmation и rollback с прерыванием питания;
- четыре канала T5838 на фактической PCB-MIC и STM32 MDF/PDM;
- BG95 mutual TLS/MQTT, dual SIM и provisioning на собранной станции;
- nRF52840 BLE, LESC pairing, IPC и serial recovery;
- QSPI, microSD, GNSS/PPS, LoRa, датчики, ток, температура и EOL-пределы.

Текущий статус firmware: `READY FOR EVT BUILD AND B01 MEASUREMENTS / HARDWARE QUALIFICATION PENDING`.

## Блокировка прошивки

Текущий release candidate всегда применяется без производственной блокировки: RDP Level 0, SWD и BOOT0 recovery сохранены, BOOT_LOCK, TrustZone, WRP и PCROP отключены. CI проверяет это по `release/firmware_lock_interlock_rev_a.json`. Отдельный production-профиль защиты можно выпустить только после полного аппаратного PASS таргета и регрессии с утвержденными численными пределами. Конкретную станцию можно блокировать только после ее собственного EOL PASS; после блокировки обязательны cold boot и проверка связи с сервером.

Host-контракт BG95 теперь покрывает автоматическое чтение SIM/оператора,
выбор APN через ответ сети или разрешённый PLMN-каталог, обязательное чтение
APN/IP/шлюза/DNS активного PDP и последовательность TLS/MQTT с fail-closed
обработкой ошибок. Полные IMSI/ICCID удерживаются только в оперативном состоянии
и включаются в отдельный heartbeat, разрешённый только через взаимный TLS;
общий server API маскирует их. Границы и отложенные до сборки станций
аппаратные доказательства зафиксированы в `BG95_MQTT_TLS_CONTRACT_REV_A.md`;
это не снимает общий `TARGET_PORT_REQUIRED` и не является сетевым EVT PASS.

Portable dual-SIM controller теперь отделяет проверяемую host-политику от
будущего target GPIO binding. Он принимает слот только после 20 ms DET debounce,
ограничивает профиль тремя попытками и 900-second hold, требует authenticated
manual assertion и audit intent/commit. При активном переключении новый слот не
может быть выбран до остановки трафика, сохранения очереди, штатного выключения
BG95, подтверждения mux High-Z и отключения modem rail. После включения
обязательны стабильный `PWR_GOOD` не менее 30 ms, 700 ms PWRKEY, полное совпадение
provisioned ICCID и attach/DNS/TLS до resume прежних event IDs. Любая ошибка,
brownout или debounced removal переводит controller в safe-off request. Это
host QG-1/QG-2, а не доказательство GPIO, реальных SIM, 100 циклов, операторов
или 24-часовой работы станции.

Safe-off request теперь сам является явной неразрывной последовательностью:
target сначала запрашивает graceful shutdown, а при его недоступности и
`CELL_STATUS=HIGH` выдаёт fallback PWRKEY 1000 ms
(внутри разрешённого аппаратного окна 650–1500 ms), подтвердить status LOW,
отключить mux, подтвердить High-Z и только затем снять modem rail. Ошибка любого
recovery action не переводит controller дальше и не допускает преждевременный
выбор слота.

Узкий portable bridge теперь связывает modem-dependent actions с BG95:
`AT+QPOWD` не считается завершённым без внешнего `CELL_STATUS=LOW`, после чего
volatile IMSI/ICCID очищаются; повторный power-on разрешён только из `OFF`.
Обратный путь требует штатного 700 ms PWRKEY, `CELL_STATUS=HIGH`, полного ICCID
из runtime автоматического network discovery и действительного online MQTT/TLS
с APN/IP/gateway/DNS read-back. Busy UART не позволяет перескочить shutdown.
Источник физического CELL_STATUS и прочие GPIO по-прежнему относятся к target.

Для EVT-PRE-20 добавлен host-compiled target GPIO contract: generated pin IDs
однозначно связывают PWRKEY/STATUS/mux/DET/PWR_GOOD/EN_MODEM с PD11, PD13, PE0,
PE2, PE3, PE5, PD0 и PD4. Адаптер проверяет полярности и запрещает rail-off до
`CELL_STATUS=LOW` и отключённого mux, а mux/PWRKEY — до непрерывных 30 ms
`PWR_GOOD`. При этом PD0 означает системный 3.3-V PG, не измерение 3V8_MODEM.
`U13_EN_N` не заведён на MCU, поэтому host различает logical command read-back
и physical fixture read-back; STM32 HAL, оснастка и измерение 3V8 остаются
target/EVT blockers.

BG95 link gate также теперь сверяет реально выбранный longest-prefix public-APN
catalog index с `pending_profile` dual-SIM controller. Поэтому даже online
MQTT/TLS с полным ICCID и валидным APN/IP/gateway/DNS не завершает switch через
другой индекс профиля. Содержимое production-каталога и durable audit backend
остаются provisioning/target blockers.

Portable store-and-forward теперь дополнен серверным application receipt:
сервер после durable processing публикует canonical CBOR с SHA-256 точного
detection payload, а fixed-memory firmware parser проверяет topic, QoS/retain и
полную identity события до маркировки outbox slot доставленным. Portable uplink
adapter сохраняет retry marker до выдачи exact `up` topic/payload и не считает
PUBACK разрешением на удаление. BG95 uplink binding использует fixed-length
`QMTPUB`: после `>` пишет ровно заявленное число binary CBOR bytes и оставляет
event pending даже после `+QMTPUB` success. Базовая BG95 state machine до
`QMTOPEN` включает direct `QMTRECV` с обязательной длиной; receipt binding после
connect проверяет этот флаг, подписывается на exact receipt topic с QoS 1 и
разбирает полный URC по byte count, сохраняя NUL/quote/CRLF/`0x1a`. Сам URC не
содержит retain-флаг, поэтому путь разрешается только явным внешним контрактом
station credential + server-only ACL + запрет retained receipt. Host QG не
заменяет target USART/DMA/ISR wiring, проверку broker policy/версии BG95 и аппаратный
recovery test.

Portable BG95 command binding использует тот же общий length-delimited parser:
после exact QoS-1 `down` subscription он передаёт только полный binary payload в
signature/journal/executor channel. Fixed-length `ack` `QMTPUB` начинается лишь
после durable `COMPLETED`; при reconnect повторная server command восстанавливает
ACK из journal без повторного side effect. Partial UART, timeout и mismatched
URC инвалидируют modem transport. Общая portable MQTT session принимает
произвольно фрагментированный raw UART, собирает line/prompt/length-delimited
URC в лимите 2304 bytes, сериализует command/receipt subscriptions, event
publish и command ACK единым TX owner. Один command frame буферизуется во время
занятого TX, следующие учитываются как требующие server retry; disconnect
очищает RAM queue и запускает ordered resubscribe. Retain в `QMTRECV` не виден и покрывается только явно подтверждённым
server-only/non-retained ACL contract. Target crypto, exact slot counts/OCTOSPI/endurance, USART/DMA/ISR,
broker policy и hardware evidence остаются открыты.

Command journal теперь имеет отдельный portable NOR adapter: каждый 88-byte
accepted/completed record занимает собственный physical erase block, callbacks
не могут выйти за логический slot, а torn commit повторно используется без
стирания соседнего record. Host QG проверяет restart roundtrip, commit-write
failure, alignment/range и erase isolation. Общий layout/bind ниже также
доказывает непересечение journal с archive и outbox. Production slot count,
OCTOSPI binding и endurance всё ещё не определены.

Portable NOR adapter выделяет каждому outbox slot отдельный erase block и
проверяет alignment/range partition, поэтому reclaim не стирает соседнее pending
event. Перед выдачей любого storage interface общий bind fail-closed проверяет
точный W25Q512JV JEDEC ID `EF 40 20`, SFDP/BFPT ёмкость 64 MiB, 4-byte geometry
и Status Register-2 QE; сброшенный QE восстанавливается с read-back. Portable
layout planner вычисляет непересекающиеся разделы: audio archive
занимает выровненный префикс NOR, за ним расположен erase-isolated command
journal, а outbox занимает хвост. Для контрольной геометрии 64 MiB / 4 KiB / 16
command slots / 256 event slots host QG проверяет 62.9375 MiB archive + 64 KiB
journal + 1 MiB outbox. Единый bind API создаёт все три adapter-а из одного
layout и ограничивает видимую archive storage точно началом journal, поэтому
независимая ошибочная инициализация диапазонов fail-closed. Точные числа слотов,
OCTOSPI HAL и endurance ещё должны быть утверждены в target memory map и
измерены на плате; host probe не заменяет проверку реального sample.

Первый target-инкремент уже фиксирует точный исходный контракт
`STM32U585VIT6Q/LQFP100`: 67 назначений из Rev.A pin map и AAD addendum,
запрет внешнего HSE, 32.768 kHz reference и пять ещё не измеренных runtime
profiles. Контракт генерируется воспроизводимо и проходит два независимых
контроля.

Второй target-инкремент закрепляет STM32CubeU5 v1.9.0 и его CMSIS-U5 commit,
добавляет официальный GCC startup/system и инженерный linker для 2 MiB flash,
768 KiB SRAM1-3 и 16 KiB SRAM4. Инженерная ARM-сборка с этим linker проходит,
но он предназначен только для первичного запуска без TrustZone, не заменяет
production-разметку secure boot/A/B и не разрешает выпуск прошивки.

Третий target-инкремент формирует воспроизводимый pinout `.ioc` для
STM32CubeMX 6.12.0 / DB.6.0.120. В нём сохранены 67 назначений, включая
отдельные fail-closed `LORA_TXEN`/`LORA_RXEN`, и устранён
конфликт EXTI8: `LORA_DIO1` перенесён на `PC2/EXTI2`, а `MIC_WAKE` оставлен на
`PA8/EXTI8`. До открытия и регенерации в зафиксированной версии CubeMX файл не
считается подтверждённым target build.

Portable слой хранения installation position реализует атомарное чередование
двух слотов, CRC32, commit-marker, read-back, monotonic version и обязательные
physical-service/authenticated-role gates. Host QG не закрывает привязку этих
слотов к страницам STM32 Flash, ресурс перезаписи и power-loss fault injection
на фактической плате.

Portable слой commissioning принимает изменение installation position только
из локального BLE-origin после BLE Secure Connections, проверки peer identity
и физического сервисного окна не более 10 минут. Обычная installer-роль может
использовать только locked policy defaults; нестандартная trust policy требует
engineer-роли. Станция сама вычисляет канонический SHA-256, требует audit intent
до записи и audit committed после read-back. Это ещё не nRF52840/GATT binding:
UUID, pairing transport, сервисный таймер и durable audit backend проверяются на
целевой связке STM32+nRF и остаются release blocker.
