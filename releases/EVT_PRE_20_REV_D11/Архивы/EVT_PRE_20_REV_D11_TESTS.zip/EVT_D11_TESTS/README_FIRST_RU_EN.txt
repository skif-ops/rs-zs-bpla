EVT-PRE-20 REV_D11, test methods, EOL records and Muhoed training
Дата / Date: 2026-11-14
Привязка исходников / Source binding: fad513d476595b8400b719dbabc0edf2a88c19f9

RU
REV_D11 является исправленным полным комплектом после оформления закупки. Заказные
параметры не изменены: PCB-MAIN 8L, PCB-PWR 4L, PCB-MIC 2L. Фабричный Altium/CAM
пакет унаследован побайтно от REV_D10. BOM, реестры и документация приведены к
фактически заказанной конфигурации. Старые конкурирующие документы REV_D7 исключены
из основного и испытательного архивов. Несколько файлов с обозначением REV_D7 внутри
Altium-архива сохранены только как точная историческая привязка уже оформленного заказа.
Они не заменяют действующие документы REV_D11 из основного архива.

Все включенные DOCX прошли проверку шаблона: Times New Roman 14 пт, в таблицах
12 пт, одинарный интервал, выравнивание по ширине, отступ первой строки 1,25 см
вне таблиц и отсутствие такого отступа в таблицах. Длинное и среднее тире не применены.

Стендовый программный выпуск 2026111201 включен полностью и остается в статусе
аппаратной проверки. Подпись STM32 Ed25519, фиксированные хеши и ключ nRF52840, APK,
отсутствие закрытых материалов и аппаратные блокировки проверены валидатором. Прошивка
разрешена для DIO-EVT-B01 и аппаратных испытаний EVT. Блокировка прошивки запрещена до
полного аппаратного PASS и отдельного производственного выпуска.

EN
REV_D11 is the corrected complete package issued after procurement. Ordered hardware
parameters are unchanged. The Altium/CAM factory payload is inherited byte-for-byte
from REV_D10. BOM and records match the ordered eight-layer PCB-MAIN baseline.
Conflicting REV_D7 documents are excluded from FULL and TESTS. REV_D7-named files
inside ALTIUM are retained only as an exact historical binding of the placed factory
order and are superseded by the current REV_D11 documents. All included DOCX files
passed the approved format audit. The complete signed bench release 2026111201 is
included and validated. It may be flashed to DIO-EVT-B01 and EVT hardware for the
required physical tests. Firmware locking remains forbidden until full hardware PASS
and a separate production release.
