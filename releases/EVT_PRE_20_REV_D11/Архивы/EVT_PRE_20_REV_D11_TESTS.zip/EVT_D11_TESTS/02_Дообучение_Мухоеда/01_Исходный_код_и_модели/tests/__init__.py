"""Tests for DAI."""

