"""Trajectory tracking package."""

