# EVT-PRE-20 bench software release 2026100601

## Русский

Статус: готово к прошивке стендового образца; аппаратная проверка обязательна.

Порядок первой установки:

1. Сохранить полный снимок option bytes STM32.
2. Применить только поля из `01_STM32/option_bytes_bench_rev_a.json`.
3. Прошить `01_STM32/dioneya_evt_pre_20_2026100601.hex` через SWD и проверить read-back.
4. Прошить `02_NRF52840/merged.hex` через отдельный nRF SWD и проверить read-back.
5. Установить `03_ANDROID/dioneya-commissioning-0.1.0-bench.20261005.apk` на выделенный Android-телефон.
6. Выполнить руководство `04_ДОКУМЕНТАЦИЯ/EVT_PRE_20_FIRMWARE_COMMISSIONING_TEST_MANUAL_REV_C.docx`.
7. Сохранить все журналы и хеши в паспорт `DIO-EVT-B01`.
8. Для полевых станций создавать CSR и проверять сертификат только средствами из `05_EOL_TOOLS` по разделу 16.4.1 руководства.

Архив не содержит закрытых ключей, паролей, keystore или производственных секретов. `release_manifest.json` и `SHA256SUMS.txt` связывают все файлы. `HARDWARE_PENDING.json` перечисляет только проверки, которым нужен физический образец или оснастка.

## English

Status: ready to flash the bench unit; hardware validation is mandatory.

Save the STM32 option-byte snapshot, apply only the controlled bench profile, flash both MCUs through their separate SWD ports, install the signed Android APK, and execute the supplied commissioning and test manual. Keep all read-back logs and hashes in the `DIO-EVT-B01` unit record. The archive contains no private key, password or keystore.
